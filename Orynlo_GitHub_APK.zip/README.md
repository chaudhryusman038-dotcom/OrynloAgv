# Orynlo Voice Desk — Android device-test source

**Delivery status: Android source project; NOT an APK.** Native Android compilation, installation, and Google Voice device testing are pending. The build environment had Java compiler modules but no Android SDK or Gradle; official SDK/Gradle download attempts timed out through its network. Do not mistake the included source checks for Android build success.

## Is app mein kya hai

- Google Voice ke upar draggable, collapsible native floating panel.
- Company/owner/phone/trucks/status, Previous, Next, Prepare, Call, Hang up, Copy.
- Next/Previous prepares a number; it never automatically places the next call.
- + Result: status, primary objection, rebuttal Pass/Fail, opener Pass/Fail, notes, follow-up date/time and time zone.
- Draft notes save while typing. Results, call history, imported leads, and exact selected lead persist on-device.
- Local SQLite dashboard, due follow-ups, search/status filters, daily calls goal and results, opener/rebuttal performance.
- CSV import with header aliases, quoted/newline fields, invalid-number reporting and normalized-phone deduplication. Existing history and Do-not-call state survive reimport.
- CSV exports for leads and call history. These are reporting exports, not a full restore/sync mechanism.
- 18-stage owner-first website/estimator/customer-portal/operations sales flow and 35 objection responses.
- Approximate follow-up notifications (15-minute alarm checks, at most one digest per hour). Battery restrictions may delay reminders.
- No Internet permission, analytics, call recording, third-party SDKs, or background screen collection.

## Google Voice integration: exact limits

The user explicitly enables Orynlo's Accessibility service. The service displays a `TYPE_ACCESSIBILITY_OVERLAY`, and inspects the Google Voice package only after a user action. A separate “draw over other apps” permission is not used by this implementation.

Prepare tries a package-scoped Android dial intent, falling back to opening Voice. It finds a unique visible phone-entry field, sets its text, and verifies the normalized number. It does not guess screen coordinates or type into an arbitrary search box. If Voice does not expose a suitable field, open its dial pad and retry or use Copy/manual paste.

Call requires the displayed number to match the selected lead and a unique visible Call control. It records a **dial request**, not a connected call. Hang up clicks a unique visible End call/Hang up control. A successful accessibility action is not proof the call ended: the user confirms **Call ended**, then saves a result. The panel blocks navigation while an unresolved call or unsaved attempt exists.

Google Voice app versions, language, account setup, Android versions and device settings can change control availability. Default semantic matching is English. Verified resource IDs can be entered in Setup; the floating panel's “Inspect Voice controls” lists visible control IDs without screen text. There are no pre-verified Google Voice resource IDs in this release.

If integration fails, the app says so. Use Voice's own Call/Hang-up controls and **Manual call started** / **Call ended** in the panel. No Google Voice account, number, subscription or calling entitlement is supplied by this app.

## Build the APK

Requires network access to Google's Android and Gradle/Maven repositories, JDK 17, Android SDK platform 35, Build Tools 34.0.0, and Gradle 8.9. The project pins Android Gradle Plugin 8.7.3; it is not claiming to use the newest tooling.

### Android Studio / local machine

1. Open this folder as an existing Android Gradle project.
2. Install SDK platform 35 and Build Tools 34.0.0. Set the SDK path using Android Studio or `local.properties` (`sdk.dir=...`).
3. Install/use Gradle 8.9. A Gradle wrapper JAR could not be fetched here, so one is not bundled. Configure Android Studio to use your local Gradle 8.9 installation, or run the command below.
4. From this directory:

```bash
gradle --no-daemon :app:assembleDebug :app:lintDebug
```

The expected artifact after a successful build is `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions (can be started from a phone)

An included **manually triggered** workflow, `.github/workflows/android.yml`, installs the build tools, runs the source checks, builds/lints, and uploads the debug APK as a workflow artifact. It has not been run in this task. Upload this project to your own repository, open Actions → Build Android APK → Run workflow, and inspect the logs. Download the artifact only after the job succeeds. GitHub availability, account requirements and artifact access depend on your account.

No repository has been created and nothing has been published for you. The workflow contains no leads, credentials or customer data. Never commit keystores, client data or local.properties.

For durable distribution use a private, securely backed-up release signing key. A new debug signature can prevent in-place updates to an earlier debug install; uninstalling would erase local data. No Play Store submission or approval is included.

## Phone setup after the build succeeds

1. Install the APK on your Android phone (minimum Android 8). Open Orynlo Voice Desk.
2. Import a UTF-8 CSV or add a lead. Header aliases include Company / Company Name / Legal Name; Owner / First Name / Contact; Phone / Phone Number / Telephone; Trucks / Power Units; Email; Lanes / State; Website.
3. Tap **Open floating panel**, read the disclosure, and enable **Orynlo calling panel** in Android Accessibility settings yourself. On devices that restrict sideloaded accessibility services, review the device's app settings guidance; the app cannot grant itself this permission.
4. Return and open the floating panel. Move/minimize it so Voice's dial pad and controls remain visible.
5. Test against a number you control or have permission to use. Prepare → confirm displayed number → Call → Hang up → confirm Call ended → + Result → Save → Next.
6. Enable reminder notifications if desired. Set the daily target in Setup.

Do not start a real prospect campaign before the device acceptance checks below pass.

## Data and calling semantics

- All app data is local. The existing web desk and its browser storage are unchanged and do not auto-sync. Export/import the original leads CSV to start in this app. Existing web call-history migration is not implemented.
- Do-not-call is sticky in this build, tied to normalized phone number; reimport cannot silently reset it.
- App restart preserves an unresolved call marker. If the Accessibility service is disabled, Setup → Resolve interrupted call lets you confirm manually that you already ended it in Voice. That button does not hang up.
- Current stage in the script is session-only; selected lead, notes and outcomes are persistent.
- Export leads and activity for your records. Clearing app data or uninstalling removes the local database. No cloud backup or full restore is included.
- Dashboard counts call requests/manual logs and saved outcomes, not verified conversations, connection time or Google Voice billing data. No timer is presented as actual talk time.
- One primary objection per call. Selecting it attaches a draft; scoring is saved with the outcome. Pass/Fail definitions appear in the script and form.
- Follow-up uses the selected prospect time zone and stores a UTC timestamp. Nonexistent/ambiguous daylight-saving times are rejected. Daily dashboard boundaries use the phone time zone.
- No automatic SMS, email, contact upload, call recording or message sending.

## Device acceptance checks — still pending

- Build and Android lint; install on the user's Android version.
- Accessibility enable/disable/reconnect, portrait/landscape, large font, keyboard, drag/minimize/close and process recreation.
- Google Voice number preparation, wrong-screen refusal, ambiguous-control refusal, configured IDs, Call, Hang up, manual fallback and fast double taps.
- Confirm that no action is performed in any other app and no current call can silently advance to another lead.
- Save a result, reopen app, restart phone, reimport same CSV and verify current lead/history/DNC.
- Follow-up zone conversion, notification permission denied/allowed, due filter and delayed reminders.
- Export, open CSV, validate rows/quotes and spreadsheet-formula neutralization.

## Validation actually completed here

Run `bash tests/run.sh` with a JDK 17 runtime containing compiler modules and Python 3:

- 15 executed Java CSV/phone/parser checks.
- All 8 Java source files parsed by the Java compiler (syntax only; no Android type resolution).
- SQLite schema execution, duplicate/DNC preservation, foreign-key integrity and result-row update.
- All Android XML files parsed; JSON playbook structure and unique objection titles checked.

Android compilation, lint, emulator UI tests, APK signing/installation and live Google Voice behavior were **not** executed.

## Files

- `app/`: native Android implementation and embedded playbook.
- `SALES_PLAYBOOK.md`: readable complete English script, updated to the owner's offer correction.
- `tests/`: runnable core and structural validation.
- `.github/workflows/android.yml`: manual APK build workflow.
- `sample-leads.csv`: one clearly fictitious formatting example; do not dial it.

## Technical references

- https://developer.android.com/reference/android/accessibilityservice/AccessibilityService
- https://developer.android.com/reference/android/view/accessibility/AccessibilityNodeInfo
- https://developer.android.com/reference/android/view/WindowManager.LayoutParams#TYPE_ACCESSIBILITY_OVERLAY
- https://developer.android.com/build/releases/agp-8-7-0-release-notes
