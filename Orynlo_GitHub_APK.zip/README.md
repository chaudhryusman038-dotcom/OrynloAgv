# Orynlo Voice Desk v0.5 — Manual Call Desk

This build is intentionally simple and manual-first.

## Floating panel
- Movable by dragging the top bar
- Resizable with − / +
- Contact company, owner, fleet size and phone always visible
- Tap phone number or COPY to put the number on the clipboard
- Previous / Next are always on the call panel
- SCRIPT opens a full-screen script view
- OBJECTIONS opens full-screen rebuttals, with common objections first
- OPEN VOICE only launches Google Voice

## What was removed
- Auto dialing
- Auto hang up
- Google Voice UI state machine
- Speaker automation
- Speech recognition / transcription
- Auto rebuttal detection
- Auto-next timers
- Background reminder receiver
- Microphone and notification permissions

Google Voice is controlled manually by the caller. Accessibility is used only to display the movable overlay.

## Sales flow
Permission opener → concise value statement → two qualifying questions → benefit-led recommendation → realistic ~1 week first-version timeline → 10-minute walkthrough close.
