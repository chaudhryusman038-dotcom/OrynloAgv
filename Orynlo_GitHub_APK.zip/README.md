# Orynlo Rapid Call Cockpit v0.4.0

Android automation-focused calling cockpit for Google Voice.

## Rapid call loop
1. Press **CALL** for the selected lead.
2. Orynlo keeps its own full-screen cockpit visible, shows contact details, says the owner's first name twice, then prepares and starts the Google Voice call underneath.
3. Use **HANG UP** to end the call. Call ending is manual-only; Orynlo does not auto-press Hang Up or infer a finished call.
4. A configurable post-call pause appears with an optional **NOTE** button.
5. When the pause expires, an unclassified call defaults to **No answer**, the next callable lead loads, its owner name is spoken twice, and the next number auto-dials.

## Live call screen
- Contact details always visible.
- Speaking style and energy are visually separate from words to say.
- Script previous/next navigation.
- Local objection button and local rebuttal library.
- Live Assist can use Android speech recognition to track the current script stage and open a matching rebuttal when recognition returns the other side's words.
- Voicemail/intercept phrases are flagged, but **HANG UP remains manual**.

## Reliability boundary
The local script, navigation, notes, contact display, local rebuttal buttons, post-call timer, next-lead sequencing and owner-name TTS do not depend on call transcription. Automatic transcript/rebuttal recognition depends on Android SpeechRecognizer receiving usable audio while Google Voice is using the microphone; Android/Google Voice do not expose a guaranteed call-audio stream to this app.

Use calling automation in accordance with applicable consent, Do-Not-Call and telemarketing rules.


## v0.4.0 Google Voice hybrid cockpit
- Lower-screen overlay leaves Google Voice call content visible above.
- Explicit Voice state machine: account chooser, profile/menu recovery, Calls home, dialpad, active call.
- Manual Speaker button plus optional automatic Speaker request.
- FIX VOICE rescue button continues navigation from the currently visible Voice screen.
- Optional advanced resource IDs for Calls tab, dialpad, call, hang-up and speaker controls.
