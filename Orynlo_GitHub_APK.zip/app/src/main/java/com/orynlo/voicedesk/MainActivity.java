package com.orynlo.voicedesk;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class MainActivity extends Activity {
    private Store db;private LinearLayout page;private String exportTable="leads";private String screen="dashboard";private String filter="All",query="";

    @Override public void onCreate(Bundle state){
        super.onCreate(state);db=new Store(this);if(state!=null)exportTable=state.getString("exportTable","leads");
        // Clean up legacy automation state from older builds. v0.5 is manual-first.
        db.prefs.edit().putBoolean("call_unresolved",false).putBoolean("live_assist",false).remove("voice_account").apply();
        if(db.activeLead()>0)db.defaultPendingNoAnswer();
        dashboard();
    }
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putString("exportTable",exportTable);}
    @Override protected void onResume(){super.onResume();if(db!=null&&screen.equals("dashboard"))dashboard();}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}

    private void base(String title){
        ScrollView sc=new ScrollView(this);sc.setBackgroundColor(Ui.BG);page=Ui.column(this);sc.addView(page);setContentView(sc);
        sc.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;});
        page.addView(Ui.text(this,"ORYNLO  /  MANUAL CALL DESK",12,Ui.MUTED));page.addView(Ui.title(this,title));
    }

    private void dashboard(){
        screen="dashboard";base("Call. Talk. Next.");
        Store.Lead l=db.current();
        if(l==null){
            LinearLayout empty=Ui.card(page);empty.addView(Ui.title(this,"Add your leads"));empty.addView(Ui.text(this,"Import a CSV or add a lead, then open the floating panel over Google Voice.",15,Ui.MUTED));
        }else{
            LinearLayout c=Ui.card(page);c.addView(Ui.label(this,"CURRENT LEAD",Ui.CYAN));c.addView(Ui.title(this,l.company));
            c.addView(Ui.text(this,(l.owner==null?"":l.owner)+"\n"+l.phone+(l.trucks==null||l.trucks.isEmpty()?"":" · "+l.trucks+" trucks"),17,Ui.INK));
            Ui.row(c,Ui.button(this,"Previous",()->move(-1)),Ui.button(this,"Next",()->move(1)));
            Ui.row(c,Ui.buttonColor(this,"+ Result (optional)",Ui.CARD,()->result(l)),Ui.buttonColor(this,"History",Ui.CARD,()->dialog("Call history",db.history(l.id))));
        }
        page.addView(Ui.buttonColor(this,"OPEN FLOATING CALL PANEL",Ui.GREEN,this::panel));
        page.addView(Ui.text(this,"The floating panel does not dial, hang up, listen, transcribe, or control Google Voice. It only keeps the lead, copyable number, Previous/Next, script and objections in front of you.",12,Ui.MUTED));
        Ui.row(page,Ui.button(this,"Import CSV",()->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),10)),Ui.button(this,"+ Add lead",this::addLead));
        Ui.row(page,Ui.button(this,"Leads",this::leads),Ui.button(this,"Script & objections",this::playbook));
        Ui.row(page,Ui.button(this,"Setup",this::settings),Ui.button(this,"Performance",()->dialog("Performance",db.performance())));
        Ui.row(page,Ui.button(this,"Export leads",()->export("leads")),Ui.button(this,"Export history",()->export("calls")));
        page.addView(Ui.text(this,"v0.5 · Manual-first · movable/resizable overlay · tap-to-copy phone · always-visible Previous/Next · full-screen script & rebuttals · no call automation.",12,Ui.MUTED));
    }

    private void move(int n){if(db.move(n)==null)Ui.toast(this,n>0?"End of queue":"Start of queue");dashboard();if(VoiceService.instance!=null)VoiceService.instance.render();}

    private void panel(){
        if(VoiceService.instance!=null){VoiceService.instance.show();return;}
        new AlertDialog.Builder(this).setTitle("Enable the floating panel")
                .setMessage("Orynlo uses Accessibility only to keep a movable panel over Google Voice. It does not auto-dial, auto-hang-up, read Google Voice controls, listen to calls, or run call automation.\n\nEnable “Orynlo calling cockpit” in Accessibility, then return and open the panel.")
                .setNegativeButton("Cancel",null).setPositiveButton("Open Accessibility",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).show();
    }

    private void result(Store.Lead l){screen="result";base("Log call result");page.addView(new ResultForm(this,db,l,this::dashboard).view);page.addView(Ui.button(this,"Back — keep draft",this::dashboard));}

    private void addLead(){
        screen="add";base("Add lead");EditText company=Ui.input(page,"Company","",InputType.TYPE_CLASS_TEXT),owner=Ui.input(page,"Owner / contact","",InputType.TYPE_CLASS_TEXT),phone=Ui.input(page,"US phone number","",InputType.TYPE_CLASS_PHONE),trucks=Ui.input(page,"Truck count (if known)","",InputType.TYPE_CLASS_NUMBER);
        page.addView(Ui.buttonColor(this,"Save lead",Ui.GREEN,()->{try{db.add(company.getText().toString(),owner.getText().toString(),phone.getText().toString(),trucks.getText().toString());dashboard();}catch(Exception e){Ui.toast(this,e.getMessage());}}));page.addView(Ui.button(this,"Back",this::dashboard));
    }

    private void leads(){
        screen="leads";base("Leads");Spinner filters=Ui.spinner(page,"Queue",new String[]{"All","Due","New","No answer","Call back","Follow-up","Send email","Interested","Qualified","Not interested","Closed / Won","Do not call"},filter);EditText search=Ui.input(page,"Company, owner or phone",query,InputType.TYPE_CLASS_TEXT);
        page.addView(Ui.button(this,"Search / apply",()->{filter=Ui.value(filters);query=search.getText().toString();leads();}));page.addView(Ui.button(this,"Back",this::dashboard));int count=0;
        for(Store.Lead l:db.leads(filter,query)){count++;LinearLayout c=Ui.card(page);c.addView(Ui.text(this,l.company+"\n"+(l.owner==null?"":l.owner)+" · "+l.phone+" · "+l.status,16,Ui.INK));if(l.follow>0)c.addView(Ui.text(this,Instant.ofEpochMilli(l.follow).atZone(ZoneId.of(l.zone)).format(DateTimeFormatter.ofPattern("MMM d, HH:mm z")),13,Ui.MUTED));c.addView(Ui.button(this,"Select lead",()->{db.select(l.id);dashboard();if(VoiceService.instance!=null)VoiceService.instance.render();}));}
        page.addView(Ui.text(this,count==0?"No matches":"Showing up to 250 matches.",13,Ui.MUTED));
    }

    private void settings(){
        screen="settings";base("Simple setup");
        page.addView(Ui.text(this,VoiceService.instance==null?"Floating panel: Accessibility not connected":"Floating panel: connected",16,VoiceService.instance==null?Ui.RED:Ui.GREEN));
        page.addView(Ui.button(this,"Accessibility / panel setup",this::panel));
        EditText target=Ui.input(page,"Daily call target",""+db.prefs.getInt("target",150),InputType.TYPE_CLASS_NUMBER);
        page.addView(Ui.buttonColor(this,"Save",Ui.GREEN,()->{try{int n=Integer.parseInt(target.getText().toString());if(n<1||n>5000)throw new IllegalArgumentException();db.prefs.edit().putInt("target",n).apply();dashboard();}catch(Exception e){Ui.toast(this,"Enter a valid daily target");}}));
        LinearLayout info=Ui.card(page);info.addView(Ui.label(this,"WHAT THE PANEL DOES",Ui.CYAN));info.addView(Ui.text(this,"• Drag it anywhere\n• − / + changes its size\n• Tap the phone number to copy\n• Previous / Next always available\n• Script opens full screen\n• Objections open full screen, common ones first\n• Open Voice only launches Google Voice — nothing is auto-clicked",14,Ui.INK));
        page.addView(Ui.button(this,"Back",this::dashboard));
    }

    private void playbook(){
        screen="playbook";base("Short call playbook");Playbook p=new Playbook(this);
        for(int i=0;i<p.stages.length();i++){JSONObject s=p.stages.optJSONObject(i);LinearLayout c=Ui.card(page);c.addView(Ui.label(this,s.optString("title"),Ui.CYAN));c.addView(Ui.text(this,s.optString("style"),13,Ui.AMBER));c.addView(Ui.text(this,s.optString("energy"),12,Ui.GREEN));c.addView(Ui.speech(this,p.personalize(s.optString("say"),db.current())));c.addView(Ui.text(this,s.optString("coach"),12,Ui.MUTED));}
        page.addView(Ui.title(this,"Objections — common first"));for(int i=0;i<p.objections.length();i++){JSONObject o=p.objections.optJSONObject(i);LinearLayout c=Ui.card(page);c.addView(Ui.label(this,o.optString("title"),i<5?Ui.PURPLE:Ui.RED));c.addView(Ui.text(this,o.optString("cue"),13,Ui.PURPLE));c.addView(Ui.text(this,o.optString("style"),12,Ui.AMBER));c.addView(Ui.speech(this,p.personalize(o.optString("say"),db.current())));}page.addView(Ui.button(this,"Back",this::dashboard));
    }

    private void dialog(String title,String text){TextView t=Ui.text(this,text,16,Ui.INK);t.setPadding(24,16,24,16);t.setTextIsSelectable(true);ScrollView sc=new ScrollView(this);sc.addView(t);new AlertDialog.Builder(this).setTitle(title).setView(sc).setPositiveButton("Close",null).show();}
    private void export(String table){exportTable=table;startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/csv").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"Orynlo-"+table+"-"+LocalDate.now()+".csv"),11);}

    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
        try{if(request==10){try(InputStream in=getContentResolver().openInputStream(data.getData())){int[] counts=db.importCsv(Ui.read(in));Ui.toast(this,counts[0]+" added · "+counts[1]+" duplicates · "+counts[2]+" invalid phones skipped");}dashboard();if(VoiceService.instance!=null)VoiceService.instance.render();}
        else if(request==11){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(db.export(exportTable).getBytes(StandardCharsets.UTF_8));}Ui.toast(this,"CSV exported");}}
        catch(Exception e){Ui.toast(this,"File operation failed: "+e.getMessage());}
    }
    @Override public void onBackPressed(){if(screen.equals("dashboard"))super.onBackPressed();else dashboard();}
}
