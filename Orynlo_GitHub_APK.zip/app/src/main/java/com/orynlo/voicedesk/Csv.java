package com.orynlo.voicedesk;

import java.util.*;

public final class Csv {
    private Csv() {}
    public static List<List<String>> parse(String source) {
        String s = source.startsWith("\uFEFF") ? source.substring(1) : source;
        ArrayList<List<String>> rows = new ArrayList<>();
        ArrayList<String> row = new ArrayList<>(); StringBuilder cell = new StringBuilder();
        boolean quoted = false, closed = false;
        for (int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if (quoted) {
                if(c=='"') { if(i+1<s.length() && s.charAt(i+1)=='"') {cell.append('"'); i++;} else {quoted=false;closed=true;} }
                else cell.append(c);
            } else if(c==',' || c=='\n' || c=='\r') {
                row.add(cell.toString()); cell.setLength(0); closed=false;
                if(c!=',') {rows.add(row);row=new ArrayList<>(); if(c=='\r' && i+1<s.length() && s.charAt(i+1)=='\n')i++;}
            } else if(c=='"' && cell.length()==0 && !closed) quoted=true;
            else if(closed && !Character.isWhitespace(c)) throw new IllegalArgumentException("Unexpected character after a quoted CSV field");
            else if(!closed) cell.append(c);
        }
        if(quoted) throw new IllegalArgumentException("Unclosed CSV quote");
        if(cell.length()>0 || !row.isEmpty() || closed) {row.add(cell.toString());rows.add(row);}
        return rows;
    }
    public static String key(String s) {return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");}
    public static String phone(String s) {
        String d=s.replaceAll("[^0-9]", "");
        if(d.length()==10)d="1"+d;
        if(d.length()!=11 || !d.startsWith("1") || d.charAt(1)<'2' || d.charAt(4)<'2')return "";
        return "+"+d;
    }
    public static String cell(String s) {
        // Stop spreadsheet formulas when opening an exported CSV.
        if(s.matches("(?s)^[\\s]*[=+@-].*"))s="'"+s;
        return "\""+s.replace("\"", "\"\"")+"\"";
    }
    public static String get(List<String> row, List<String> heads, String... names) {
        for(String n:names) {int i=heads.indexOf(key(n));if(i>=0 && i<row.size())return row.get(i).trim();}
        return "";
    }
}
