package com.orynlo.voicedesk;
import android.content.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.time.*;
import java.time.format.*;

public final class ResultForm {
    private static final String[] RATINGS={"Unscored","Pass","Fail"};
    public static final String[] ZONES={"America/New_York","America/Chicago","America/Denver","America/Los_Angeles","America/Phoenix","Asia/Karachi","UTC"};
    private final Store db;private final Store.Lead lead;private final Spinner status,objection,score,opener,zone;private final EditText notes,date;private boolean saved=false;
    public final LinearLayout view;
    public ResultForm(Context c,Store db,Store.Lead lead,Runnable done){
        this.db=db;this.lead=lead;Playbook play=new Playbook(c);JSONObject draft;
        try{draft=new JSONObject(db.prefs.getString("draft_"+lead.id,"{}"));}catch(Exception e){draft=new JSONObject();}
        view=Ui.column(c);view.addView(Ui.title(c,"+ Call result"));view.addView(Ui.text(c,lead.company+" · "+lead.phone,13,Ui.MUTED));
        String[] outcomes=new String[Store.STATUSES.length+1];outcomes[0]="Select outcome";System.arraycopy(Store.STATUSES,0,outcomes,1,Store.STATUSES.length);
        status=Ui.spinner(view,"Call outcome",outcomes,draft.optString("status","Select outcome"));
        objection=Ui.spinner(view,"Primary objection used",play.objectionNames(),draft.optString("objection","None"));
        TextView response=Ui.text(c,play.response(Ui.value(objection)),16,Ui.INK);view.addView(response);
        score=Ui.spinner(view,"Rebuttal outcome",RATINGS,draft.optString("score","Unscored"));
        opener=Ui.spinner(view,"Opener outcome",RATINGS,draft.optString("opener","Unscored"));
        notes=Ui.input(view,"Notes — draft saves as you type",draft.optString("notes",lead.notes),android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        notes.setMinLines(2);
        zone=Ui.spinner(view,"Follow-up time zone",ZONES,draft.optString("zone",lead.zone));
        String old=lead.follow>0?Instant.ofEpochMilli(lead.follow).atZone(ZoneId.of(lead.zone)).format(DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm")):"";
        date=Ui.input(view,"Follow-up: YYYY-MM-DD HH:mm (blank = none)",draft.optString("date",old),android.text.InputType.TYPE_CLASS_DATETIME);
        view.addView(Ui.text(c,"Call back / Follow-up needs a future date. Reminder timing is approximate. Pass = meaningful conversation or agreed next step; leave Unscored if uncertain.",12,Ui.MUTED));
        TextWatcher watch=new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int d){}public void onTextChanged(CharSequence s,int a,int b,int d){persist();}public void afterTextChanged(Editable e){}};
        notes.addTextChangedListener(watch);date.addTextChangedListener(watch);
        AdapterView.OnItemSelectedListener select=new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?>p,View v,int n,long id){response.setText(play.personalize(play.response(Ui.value(objection)),lead));persist();}public void onNothingSelected(AdapterView<?>p){}};
        for(Spinner s:new Spinner[]{status,objection,score,opener,zone})s.setOnItemSelectedListener(select);
        view.addView(Ui.button(c,"Save result",()->{if(saved)return;try{
            VoiceService service=VoiceService.instance;
            if(db.prefs.getBoolean("call_unresolved",false))throw new IllegalArgumentException("End the call first, then confirm Call ended in the panel.");
            String dateText=date.getText().toString().trim(), outcome=Ui.value(status);long follow=0;
            if(!java.util.Arrays.asList(Store.STATUSES).contains(outcome))throw new IllegalArgumentException("Select the actual call outcome");
            if(!dateText.isEmpty()&&!outcome.equals("Do not call")){
                LocalDateTime local=LocalDateTime.parse(dateText,DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm").withResolverStyle(ResolverStyle.STRICT));ZoneId z=ZoneId.of(Ui.value(zone));
                if(z.getRules().getValidOffsets(local).size()!=1)throw new IllegalArgumentException("This time is skipped or repeated by daylight saving. Pick an unambiguous time.");
                follow=local.atZone(z).toInstant().toEpochMilli();if(follow<=System.currentTimeMillis())throw new IllegalArgumentException("Choose a future follow-up time");
            }
            if((outcome.equals("Call back")||outcome.equals("Follow-up"))&&follow==0)throw new IllegalArgumentException("Set the agreed callback date and time");
            if(lead.dnc&&!outcome.equals("Do not call"))throw new IllegalArgumentException("This number remains Do not call");
            db.result(lead.id,outcome,Ui.value(objection),Ui.value(objection).equals("None")?"Unscored":Ui.value(score),Ui.value(opener),notes.getText().toString(),follow,Ui.value(zone));saved=true;
            ReminderReceiver.schedule(c);Ui.toast(c,"Saved to dashboard");done.run();
        }catch(DateTimeException e){Ui.toast(c,"Use YYYY-MM-DD HH:mm, for example 2026-10-01 09:30");}catch(Exception e){Ui.toast(c,e.getMessage());}}));
    }
    private void persist(){if(saved)return;try{JSONObject j=new JSONObject();j.put("status",Ui.value(status));j.put("objection",Ui.value(objection));j.put("score",Ui.value(score));j.put("opener",Ui.value(opener));j.put("zone",Ui.value(zone));j.put("date",date.getText());j.put("notes",notes.getText());db.prefs.edit().putString("draft_"+lead.id,j.toString()).apply();}catch(Exception ignored){}}
}
