package com.orynlo.voicedesk;
import android.content.Context;
import org.json.*;
import java.util.*;

public final class Playbook {
    public final JSONArray stages,objections;
    private final JSONObject machine;
    public Playbook(Context c){try(var in=c.getAssets().open("playbook.json")){JSONObject j=new JSONObject(Ui.read(in));stages=j.getJSONArray("stages");objections=j.getJSONArray("objections");machine=j.optJSONObject("machine_audio");}catch(Exception e){throw new IllegalStateException("Playbook unavailable",e);}}
    public String personalize(String s,Store.Lead l){String first=l==null||l.owner==null||l.owner.trim().isEmpty()?"there":l.owner.split("\\s+")[0];return s.replace("{first}",first).replace("{company}",l==null?"your company":l.company).replace("{trucks}",l==null||l.trucks==null||l.trucks.trim().isEmpty()?"[verify fleet size]":l.trucks);}
    public JSONObject stage(int i){return stages.optJSONObject(Math.max(0,Math.min(i,stages.length()-1)));}
    public String[] objectionNames(){String[] r=new String[objections.length()+1];r[0]="None";for(int i=0;i<objections.length();i++)r[i+1]=objections.optJSONObject(i).optString("title");return r;}
    public JSONObject objection(String name){for(int i=0;i<objections.length();i++){JSONObject o=objections.optJSONObject(i);if(o.optString("title").equals(name))return o;}return null;}
    public String response(String name){JSONObject o=objection(name);return o==null?"Select the objection you actually heard.":o.optString("say");}
    public String matchObjection(String transcript){String t=norm(transcript);if(t.length()<5)return null;Set<String> heard=tokens(t);for(int i=0;i<objections.length();i++){JSONObject o=objections.optJSONObject(i);JSONArray p=o.optJSONArray("patterns");if(p==null)continue;for(int k=0;k<p.length();k++){String q=norm(p.optString(k));if(q.isEmpty())continue;if(t.contains(q))return o.optString("title");Set<String> want=tokens(q);if(!want.isEmpty()){int hit=0;for(String x:want)if(heard.contains(x))hit++;double ratio=(double)hit/(double)want.size();if(hit>=2&&ratio>=0.66)return o.optString("title");}}}return null;}
    public boolean stageSpoken(int index,String transcript){JSONObject s=stage(index);if(s==null)return false;String t=norm(transcript);if(t.length()<8)return false;JSONArray keys=s.optJSONArray("keywords");int hits=0,needed=2;if(keys!=null){for(int i=0;i<keys.length();i++){String q=norm(keys.optString(i));if(!q.isEmpty()&&t.contains(q))hits++;}needed=Math.min(2,Math.max(1,keys.length()/2));if(hits>=needed)return true;}Set<String> target=tokens(personalize(s.optString("say"),null)),heard=tokens(t);if(target.isEmpty())return false;int overlap=0;for(String x:target)if(heard.contains(x))overlap++;return overlap>=Math.max(4,(int)Math.ceil(target.size()*0.36));}
    public String machineDisposition(String transcript){String t=norm(transcript);if(machine==null||t.isEmpty())return null;if(matches(machine.optJSONArray("voicemail_patterns"),t))return "Voicemail";if(matches(machine.optJSONArray("intercept_patterns"),t))return "Wrong number";return null;}
    private boolean matches(JSONArray a,String t){if(a==null)return false;for(int i=0;i<a.length();i++){String q=norm(a.optString(i));if(!q.isEmpty()&&t.contains(q))return true;}return false;}
    private static String norm(String s){return (s==null?"":s).toLowerCase(Locale.US).replaceAll("[^a-z0-9']+"," ").trim();}
    private static Set<String> tokens(String s){HashSet<String> r=new HashSet<>();for(String x:norm(s).split("\\s+"))if(x.length()>3&&!STOP.contains(x))r.add(x);return r;}
    private static final Set<String> STOP=new HashSet<>(Arrays.asList("this","that","with","your","from","what","when","then","they","them","have","will","would","could","about","into","just","right","really","there","here","does","more","than","once","every","team","customer","customers"));
}
