package com.orynlo.voicedesk;
import android.content.Context;
import org.json.*;
import java.nio.charset.StandardCharsets;
public final class Playbook {
    public final JSONArray stages,objections;
    public Playbook(Context c){try(var in=c.getAssets().open("playbook.json")){JSONObject j=new JSONObject(Ui.read(in));stages=j.getJSONArray("stages");objections=j.getJSONArray("objections");}catch(Exception e){throw new IllegalStateException("Playbook unavailable",e);}}
    public String personalize(String s,Store.Lead l){String first=l==null||l.owner==null||l.owner.trim().isEmpty()?"there":l.owner.split("\\s+")[0];return s.replace("{first}",first).replace("{company}",l==null?"your company":l.company).replace("{trucks}",l==null||l.trucks==null||l.trucks.trim().isEmpty()?"[verify fleet size]":l.trucks);}
    public String[] objectionNames(){String[] r=new String[objections.length()+1];r[0]="None";for(int i=0;i<objections.length();i++)r[i+1]=objections.optJSONObject(i).optString("title");return r;}
    public String response(String name){for(int i=0;i<objections.length();i++){JSONObject o=objections.optJSONObject(i);if(o.optString("title").equals(name))return o.optString("say");}return "Select the objection you actually heard. Pass / Fail rates measure the response, not the prospect.";}
}
