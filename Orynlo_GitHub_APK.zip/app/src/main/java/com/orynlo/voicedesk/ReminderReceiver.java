package com.orynlo.voicedesk;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.*;
public class ReminderReceiver extends BroadcastReceiver {
    public static void schedule(Context c){
        AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p=PendingIntent.getBroadcast(c,1,new Intent(c,ReminderReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+15*60*1000,p);
    }
    @Override public void onReceive(Context c,Intent intent){schedule(c);if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()))return;Store db=new Store(c);try{
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        List<Store.Lead> due=db.leads("Due","");if(due.isEmpty())return;
        // At most one digest per hour, including after receiver/process restarts.
        long now=System.currentTimeMillis();if(now-db.prefs.getLong("lastReminder",0)<3600000)return;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("followups","Follow-up reminders",NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent open=PendingIntent.getActivity(c,2,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        nm.notify(17,new Notification.Builder(c,"followups").setSmallIcon(com.orynlo.voicedesk.R.drawable.ic_desk).setContentTitle("Orynlo follow-ups due").setContentText(due.size()+" due. Open your dashboard to review.").setContentIntent(open).setAutoCancel(true).build());db.prefs.edit().putLong("lastReminder",now).apply();
    }finally{db.close();}}
}
