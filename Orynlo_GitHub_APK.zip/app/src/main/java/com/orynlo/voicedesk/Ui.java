package com.orynlo.voicedesk;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
public final class Ui {
    public static final int BG=Color.rgb(5,13,24),CARD=Color.rgb(14,29,47),BLUE=Color.rgb(45,100,245),INK=Color.rgb(239,246,255),MUTED=Color.rgb(151,176,205),AMBER=Color.rgb(255,190,77),GREEN=Color.rgb(79,220,157),PURPLE=Color.rgb(190,132,255),RED=Color.rgb(255,104,122),CYAN=Color.rgb(103,213,255);
    public static int dp(Context c,int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
    public static GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    public static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(c,14),dp(c,10),dp(c,14),dp(c,10));return l;}
    public static TextView text(Context c,String s,int size,int color){TextView t=new TextView(c);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(c,5),0,dp(c,5));t.setTextIsSelectable(false);return t;}
    public static TextView title(Context c,String s){TextView t=text(c,s,22,INK);t.setTypeface(null,Typeface.BOLD);return t;}
    public static TextView label(Context c,String s,int color){TextView t=text(c,s.toUpperCase(),11,color);t.setTypeface(null,Typeface.BOLD);t.setLetterSpacing(.08f);return t;}
    public static TextView speech(Context c,String s){TextView t=text(c,s,24,INK);t.setTypeface(null,Typeface.BOLD);t.setLineSpacing(0,1.08f);return t;}
    public static Button button(Context c,String s,Runnable r){return buttonColor(c,s,BLUE,r);}
    public static Button buttonColor(Context c,String s,int color,Runnable r){Button b=new Button(c);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(INK);b.setMinHeight(dp(c,50));b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));b.setOnClickListener(v->r.run());return b;}
    public static void row(LinearLayout p,View... views){LinearLayout r=new LinearLayout(p.getContext());for(View v:views){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(2,2,2,2);r.addView(v,lp);}p.addView(r);}
    public static LinearLayout card(LinearLayout p){LinearLayout l=column(p.getContext());l.setBackground(bg(CARD,18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,8,0,8);p.addView(l,lp);return l;}
    public static EditText input(LinearLayout p,String label,String value,int type){p.addView(text(p.getContext(),label,12,MUTED));EditText e=new EditText(p.getContext());e.setTextColor(INK);e.setTextSize(16);e.setInputType(type);e.setText(value);e.setMinHeight(dp(p.getContext(),48));p.addView(e);return e;}
    public static Spinner spinner(LinearLayout p,String label,String[] items,String selected){Context c=p.getContext();p.addView(text(c,label,12,MUTED));Spinner s=new Spinner(c);ArrayAdapter<String>a=new ArrayAdapter<>(c,android.R.layout.simple_spinner_dropdown_item,items);s.setAdapter(a);s.setMinimumHeight(dp(c,48));for(int i=0;i<items.length;i++)if(items[i].equals(selected))s.setSelection(i);p.addView(s);return s;}
    public static String value(Spinner s){return String.valueOf(s.getSelectedItem());}
    public static void toast(Context c,String s){Toast.makeText(c,s,Toast.LENGTH_LONG).show();}
    public static String read(InputStream in)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>10*1024*1024)throw new IOException("File exceeds 10 MB limit");}return out.toString(StandardCharsets.UTF_8.name());}
}
