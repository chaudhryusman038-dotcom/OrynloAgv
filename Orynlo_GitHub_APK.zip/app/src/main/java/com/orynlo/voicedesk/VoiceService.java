package com.orynlo.voicedesk;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.*;
import org.json.JSONObject;

/**
 * Manual-first floating call desk.
 *
 * Deliberately does NOT automate Google Voice. No auto dialing, auto hangup,
 * speech recognition, timers, account selection, or background call logic.
 * The accessibility service exists only so the user can keep a movable overlay
 * above Google Voice while manually controlling the call underneath it.
 */
public class VoiceService extends AccessibilityService {
    public static final String VOICE="com.google.android.apps.googlevoice";
    public static VoiceService instance;

    private Store db;
    private Playbook playbook;
    private WindowManager wm;
    private LinearLayout shell;
    private WindowManager.LayoutParams params;
    private int stage=0;
    private String screen="bar"; // bar | script | objections | rebuttal
    private String selectedObjection=null;
    private float dragDownRawX,dragDownRawY;
    private int dragStartX,dragStartY;

    @Override protected void onServiceConnected(){
        instance=this;
        db=new Store(this);
        playbook=new Playbook(this);
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        if(db.prefs.getBoolean("panel",false))show();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event){ /* intentionally no automation */ }
    @Override public void onInterrupt(){ }
    @Override public void onDestroy(){remove();if(db!=null)db.close();instance=null;super.onDestroy();}

    public void show(){db.prefs.edit().putBoolean("panel",true).apply();screen="bar";render();}
    public void hide(){db.prefs.edit().putBoolean("panel",false).apply();remove();}
    public void resumeAfterNote(){screen="bar";render();}

    private void remove(){if(shell!=null){try{wm.removeView(shell);}catch(Exception ignored){}shell=null;}}

    private WindowManager.LayoutParams compactParams(){
        int screenW=getResources().getDisplayMetrics().widthPixels;
        int screenH=getResources().getDisplayMetrics().heightPixels;
        int level=Math.max(0,Math.min(3,db.prefs.getInt("panel_size_level",1)));
        int[] widths={64,82,94,100};
        int[] heights={34,42,50,58};
        int width=Math.min(screenW,Math.max(Ui.dp(this,260),Math.round(screenW*(widths[level]/100f))));
        int height=Math.min(screenH,Math.max(Ui.dp(this,300),Math.round(screenH*(heights[level]/100f))));
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(width,height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.START;
        int defaultX=Math.max(0,(screenW-width)/2),defaultY=Math.max(0,screenH-height-Ui.dp(this,16));
        p.x=Math.max(0,Math.min(db.prefs.getInt("panel_x",defaultX),Math.max(0,screenW-width)));
        p.y=Math.max(0,Math.min(db.prefs.getInt("panel_y",defaultY),Math.max(0,screenH-height)));
        return p;
    }

    private WindowManager.LayoutParams fullParams(){
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(-1,-1,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.START;p.x=0;p.y=0;return p;
    }

    public void render(){
        remove();
        shell=Ui.column(this);shell.setBackgroundColor(Ui.BG);shell.setPadding(Ui.dp(this,10),Ui.dp(this,6),Ui.dp(this,10),Ui.dp(this,8));
        params=screen.equals("bar")?compactParams():fullParams();
        if(screen.equals("bar"))renderBar();
        else if(screen.equals("script"))renderFullScript();
        else if(screen.equals("objections"))renderObjectionList();
        else renderRebuttal();
        wm.addView(shell,params);
    }

    private void renderBar(){
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        TextView drag=Ui.text(this,"ORYNLO  ·  DRAG",12,Ui.CYAN);drag.setTypeface(null,android.graphics.Typeface.BOLD);drag.setPadding(Ui.dp(this,6),Ui.dp(this,8),Ui.dp(this,6),Ui.dp(this,8));drag.setOnTouchListener(this::dragPanel);
        header.addView(drag,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(Ui.buttonColor(this,"−",Ui.CARD,()->resize(-1)),new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,42)));
        header.addView(Ui.buttonColor(this,"+",Ui.CARD,()->resize(1)),new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,42)));
        header.addView(Ui.buttonColor(this,"×",Ui.CARD,this::hide),new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,42)));
        shell.addView(header);

        Store.Lead l=db.current();
        LinearLayout card=Ui.card(shell);
        if(l==null){card.addView(Ui.text(this,"No lead selected. Import or add leads in the app.",15,Ui.MUTED));return;}
        card.addView(Ui.text(this,l.company,17,Ui.INK));
        String owner=(l.owner==null||l.owner.trim().isEmpty())?"Owner name unavailable":l.owner;
        String trucks=(l.trucks==null||l.trucks.trim().isEmpty())?"Fleet unknown":l.trucks+" trucks";
        card.addView(Ui.text(this,owner+"  ·  "+trucks,13,Ui.GREEN));
        TextView phone=Ui.text(this,l.phone+"   ·   TAP TO COPY",16,Ui.CYAN);phone.setTypeface(null,android.graphics.Typeface.BOLD);phone.setPadding(Ui.dp(this,8),Ui.dp(this,9),Ui.dp(this,8),Ui.dp(this,9));phone.setBackground(Ui.bg(Ui.CARD,12));phone.setOnClickListener(v->copyPhone(l.phone));card.addView(phone);

        Ui.row(shell,
                Ui.buttonColor(this,"‹ PREVIOUS",Ui.CARD,()->moveLead(-1)),
                Ui.buttonColor(this,"COPY",Ui.BLUE,()->copyPhone(l.phone)),
                Ui.buttonColor(this,"NEXT ›",Ui.CARD,()->moveLead(1)));
        Ui.row(shell,
                Ui.buttonColor(this,"SCRIPT",Ui.GREEN,()->{screen="script";render();}),
                Ui.buttonColor(this,"OBJECTIONS",Ui.PURPLE,()->{screen="objections";render();}),
                Ui.buttonColor(this,"OPEN VOICE",Ui.CARD,this::openVoice));
        shell.addView(Ui.text(this,"Manual-first: copy the number, paste it in Google Voice, and control the call yourself. Nothing auto-dials or auto-hangs-up.",10,Ui.MUTED));
    }

    private void renderFullScript(){
        topBack("CALL SCRIPT");
        ScrollView sc=new ScrollView(this);LinearLayout body=Ui.column(this);sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        JSONObject s=playbook.stage(stage);
        body.addView(Ui.label(this,s.optString("title")+"  ·  "+(stage+1)+"/"+playbook.stages.length(),Ui.CYAN));
        body.addView(Ui.text(this,s.optString("style"),14,Ui.AMBER));
        body.addView(Ui.text(this,s.optString("energy"),13,Ui.GREEN));
        LinearLayout speech=Ui.card(body);speech.addView(Ui.speech(this,playbook.personalize(s.optString("say"),db.current())));
        body.addView(Ui.label(this,"COACH — DO NOT READ",Ui.MUTED));
        body.addView(Ui.text(this,s.optString("coach"),13,Ui.MUTED));
        Ui.row(shell,
                Ui.buttonColor(this,"‹ PREV LINE",Ui.CARD,()->{stage=Math.max(0,stage-1);render();}),
                Ui.buttonColor(this,"NEXT LINE ›",Ui.BLUE,()->{stage=Math.min(playbook.stages.length()-1,stage+1);render();}));
        Ui.row(shell,
                Ui.buttonColor(this,"‹ LEAD",Ui.CARD,()->moveLead(-1)),
                Ui.buttonColor(this,"OBJECTIONS",Ui.PURPLE,()->{screen="objections";render();}),
                Ui.buttonColor(this,"LEAD ›",Ui.CARD,()->moveLead(1)));
    }

    private void renderObjectionList(){
        topBack("OBJECTIONS");
        ScrollView sc=new ScrollView(this);LinearLayout body=Ui.column(this);sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        body.addView(Ui.text(this,"Tap what you heard. Most common objections are first.",13,Ui.MUTED));
        for(int i=0;i<playbook.objections.length();i++){
            if(i==0)body.addView(Ui.label(this,"MOST COMMON",Ui.PURPLE));
            if(i==5)body.addView(Ui.label(this,"MORE OBJECTIONS",Ui.MUTED));
            JSONObject o=playbook.objections.optJSONObject(i);String n=o.optString("title");
            body.addView(Ui.buttonColor(this,n,i<5?Ui.PURPLE:Ui.CARD,()->{selectedObjection=n;screen="rebuttal";render();}));
        }
    }

    private void renderRebuttal(){
        topBack("REBUTTAL");
        JSONObject o=playbook.objection(selectedObjection);
        ScrollView sc=new ScrollView(this);LinearLayout body=Ui.column(this);sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        if(o==null){body.addView(Ui.text(this,"Choose an objection first.",15,Ui.MUTED));return;}
        body.addView(Ui.label(this,o.optString("title"),Ui.RED));
        body.addView(Ui.label(this,"COACH — DO NOT READ",Ui.PURPLE));
        body.addView(Ui.text(this,o.optString("cue"),14,Ui.PURPLE));
        body.addView(Ui.text(this,o.optString("style"),13,Ui.AMBER));
        body.addView(Ui.text(this,o.optString("energy"),12,Ui.GREEN));
        LinearLayout c=Ui.card(body);c.addView(Ui.speech(this,playbook.personalize(o.optString("say"),db.current())));
        Ui.row(shell,Ui.buttonColor(this,"BACK TO SCRIPT",Ui.GREEN,()->{screen="script";render();}),Ui.buttonColor(this,"ALL OBJECTIONS",Ui.CARD,()->{screen="objections";render();}));
    }

    private void topBack(String title){
        LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(Ui.buttonColor(this,"← PANEL",Ui.CARD,()->{screen="bar";render();}),new LinearLayout.LayoutParams(Ui.dp(this,96),Ui.dp(this,46)));
        TextView t=Ui.text(this,title,15,Ui.CYAN);t.setTypeface(null,android.graphics.Typeface.BOLD);t.setGravity(Gravity.CENTER);h.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        h.addView(Ui.buttonColor(this,"×",Ui.CARD,this::hide),new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,46)));shell.addView(h);
    }

    private void moveLead(int dir){
        Store.Lead n=db.move(dir);
        if(n==null){Ui.toast(this,dir>0?"End of lead list":"Start of lead list");return;}
        stage=0;selectedObjection=null;
        Ui.toast(this,(dir>0?"Next: ":"Previous: ")+n.company);
        render();
    }

    private void copyPhone(String phone){
        if(phone==null||phone.trim().isEmpty()){Ui.toast(this,"No phone number");return;}
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Orynlo phone",phone));
        Ui.toast(this,"Copied "+phone);
    }

    private void openVoice(){
        try{
            Intent i=getPackageManager().getLaunchIntentForPackage(VOICE);
            if(i==null){Ui.toast(this,"Google Voice is not installed");return;}
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);
        }catch(Exception e){Ui.toast(this,"Could not open Google Voice");}
    }

    private boolean dragPanel(View v,MotionEvent e){
        if(params==null||shell==null||!screen.equals("bar"))return false;
        if(e.getAction()==MotionEvent.ACTION_DOWN){dragDownRawX=e.getRawX();dragDownRawY=e.getRawY();dragStartX=params.x;dragStartY=params.y;return true;}
        if(e.getAction()==MotionEvent.ACTION_MOVE){
            int sw=getResources().getDisplayMetrics().widthPixels,sh=getResources().getDisplayMetrics().heightPixels;
            int nx=dragStartX+Math.round(e.getRawX()-dragDownRawX),ny=dragStartY+Math.round(e.getRawY()-dragDownRawY);
            params.x=Math.max(0,Math.min(nx,Math.max(0,sw-params.width)));params.y=Math.max(0,Math.min(ny,Math.max(0,sh-params.height)));
            try{wm.updateViewLayout(shell,params);}catch(Exception ignored){}return true;
        }
        if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){db.prefs.edit().putInt("panel_x",params.x).putInt("panel_y",params.y).apply();return true;}
        return false;
    }

    private void resize(int d){int n=Math.max(0,Math.min(3,db.prefs.getInt("panel_size_level",1)+d));db.prefs.edit().putInt("panel_size_level",n).apply();render();}
}
