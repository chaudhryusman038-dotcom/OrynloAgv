package com.orynlo.voicedesk;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import java.util.*;
import org.json.JSONObject;

/** User-triggered, package-scoped Google Voice adapter; never uses screen coordinates. */
public class VoiceService extends AccessibilityService {
    public static final String VOICE="com.google.android.apps.googlevoice";
    public static VoiceService instance;
    private Store db;private WindowManager wm;private LinearLayout shell;private WindowManager.LayoutParams params;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean minimized=false;private int stage=0;private String message="Ready · prepare a number to begin";
    private long pendingLead=0,deadline=0;private boolean commandBusy=false;
    @Override protected void onServiceConnected(){instance=this;db=new Store(this);wm=(WindowManager)getSystemService(WINDOW_SERVICE);if(db.prefs.getBoolean("panel",false))show();}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){/* No background reading: actions inspect Voice only after the caller taps. */}
    @Override public void onInterrupt(){pendingLead=0;commandBusy=false;message="Interrupted. Re-open Google Voice and retry.";}
    @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);remove();instance=null;if(db!=null)db.close();super.onDestroy();}
    public void show(){db.prefs.edit().putBoolean("panel",true).apply();minimized=false;render();}
    public boolean navigationLocked(){return db.prefs.getBoolean("call_unresolved",false);}
    private void remove(){if(shell!=null){try{wm.removeView(shell);}catch(Exception ignored){}shell=null;}}
    private void hide(){pendingLead=0;commandBusy=false;db.prefs.edit().putBoolean("panel",false).apply();remove();}
    public boolean canChangeLead(){if(navigationLocked()||db.activeLead()>0){Ui.toast(this,"End the call and save its result before changing leads.");return false;}return true;}
    private AccessibilityNodeInfo voiceRoot(){
        AccessibilityNodeInfo r=getRootInActiveWindow();
        if(r!=null&&VOICE.contentEquals(r.getPackageName()==null?"":r.getPackageName()))return r;
        // A focusable result form can be the active window: only use an active/focused Voice application window.
        for(AccessibilityWindowInfo w:getWindows())if(w.getType()==AccessibilityWindowInfo.TYPE_APPLICATION&&(w.isActive()||w.isFocused())){
            r=w.getRoot();if(r!=null&&VOICE.contentEquals(r.getPackageName()==null?"":r.getPackageName()))return r;
        }
        return null;
    }
    private List<AccessibilityNodeInfo> nodes(AccessibilityNodeInfo root){ArrayList<AccessibilityNodeInfo> result=new ArrayList<>();if(root==null)return result;ArrayDeque<AccessibilityNodeInfo> q=new ArrayDeque<>();q.add(root);while(!q.isEmpty()&&result.size()<500){AccessibilityNodeInfo n=q.remove();result.add(n);for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo child=n.getChild(i);if(child!=null)q.add(child);}}return result;}
    private String label(AccessibilityNodeInfo n){return n.getContentDescription()!=null?n.getContentDescription().toString().trim():n.getText()!=null?n.getText().toString().trim():"";}
    private AccessibilityNodeInfo uniqueControl(AccessibilityNodeInfo root,String pref,String... accepted){
        String configured=db.prefs.getString(pref,"").trim();List<AccessibilityNodeInfo> matches=new ArrayList<>();
        for(AccessibilityNodeInfo n:nodes(root))if(n.isVisibleToUser()&&n.isEnabled()){
            boolean match=!configured.isEmpty()?configured.equals(n.getViewIdResourceName()):Arrays.stream(accepted).anyMatch(a->a.equalsIgnoreCase(label(n)));
            if(match){AccessibilityNodeInfo target=n;for(int i=0;i<3&&!target.isClickable()&&target.getParent()!=null;i++)target=target.getParent();if(target.isClickable()&&!matches.contains(target))matches.add(target);}
        }
        return matches.size()==1?matches.get(0):null;
    }
    private AccessibilityNodeInfo numberField(AccessibilityNodeInfo root,String phone){
        String configured=db.prefs.getString("number_id","").trim();List<AccessibilityNodeInfo> result=new ArrayList<>();
        for(AccessibilityNodeInfo n:nodes(root))if(n.isVisibleToUser()&&n.isEnabled()&&n.isEditable()){
            String hint=n.getHintText()==null?"":n.getHintText().toString();String descriptor=(label(n)+" "+hint).toLowerCase(Locale.US);
            boolean isPhone=(n.getInputType()&android.text.InputType.TYPE_MASK_CLASS)==android.text.InputType.TYPE_CLASS_PHONE;
            boolean same=phone.equals(Csv.phone(n.getText()==null?"":n.getText().toString()));
            if(!configured.isEmpty()?configured.equals(n.getViewIdResourceName()):isPhone||same||descriptor.contains("phone number")||descriptor.contains("enter a number"))result.add(n);
        }
        return result.size()==1?result.get(0):null;
    }
    public void prepare(){
        if(!canChangeLead())return;Store.Lead lead=db.current();if(lead==null){Ui.toast(this,"Import or add leads in Dashboard first");return;}if(lead.dnc){say("Do not call: this number is blocked.");return;}
        pendingLead=lead.id;deadline=System.currentTimeMillis()+8000;commandBusy=true;
        db.prefs.edit().remove("prepared").apply();
        Intent dial=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+lead.phone)).setPackage(VOICE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try{startActivity(dial);}catch(Exception e){Intent launch=getPackageManager().getLaunchIntentForPackage(VOICE);if(launch==null){pendingLead=0;commandBusy=false;say("Google Voice is not installed or cannot be opened.");return;}startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
        say("Preparing number… open the Voice dial pad if needed.");handler.postDelayed(this::tryFill,450);
    }
    private void tryFill(){
        if(pendingLead==0)return;Store.Lead lead=db.lead(pendingLead);if(lead==null||lead.dnc||db.current()==null||db.current().id!=lead.id){pendingLead=0;commandBusy=false;return;}
        AccessibilityNodeInfo root=voiceRoot();AccessibilityNodeInfo field=numberField(root,lead.phone);
        if(field!=null){
            String current=field.getText()==null?"":field.getText().toString();
            if(lead.phone.equals(Csv.phone(current))){db.prefs.edit().putLong("prepared",lead.id).apply();pendingLead=0;commandBusy=false;say("Number verified · tap Call when ready");return;}
            Bundle args=new Bundle();args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,lead.phone);
            field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args);
        }
        if(System.currentTimeMillis()<deadline){handler.postDelayed(this::tryFill,400);return;}
        pendingLead=0;commandBusy=false;say("Could not verify the Voice number field. Open the dial pad, then tap Prepare. Copy is available.");
    }
    private void call(){
        if(commandBusy||navigationLocked())return;Store.Lead lead=db.current();if(lead==null||lead.dnc){say("No callable lead selected.");return;}
        if(db.activeLead()>0){say("Save the previous call result first.");return;}
        AccessibilityNodeInfo root=voiceRoot(),field=numberField(root,lead.phone);
        if(field==null||field.getText()==null||!lead.phone.equals(Csv.phone(field.getText().toString()))){say("Number not verified. Tap Prepare, or call manually in Voice.");return;}
        AccessibilityNodeInfo button=uniqueControl(root,"call_id","Call","Place call","Call "+lead.phone);
        if(button==null){say("A unique Call control was not found. Call in Voice, then tap Manual call started here.");return;}
        commandBusy=true;
        if(button.performAction(AccessibilityNodeInfo.ACTION_CLICK)){db.attempt(lead.id,"Dial requested");db.prefs.edit().putBoolean("call_unresolved",true).commit();say("Call requested · connection is not verified");}
        else say("Voice did not accept Call. Use its Call button manually.");
        handler.postDelayed(()->commandBusy=false,1200);
    }
    private void hang(){
        if(commandBusy)return;AccessibilityNodeInfo root=voiceRoot();AccessibilityNodeInfo button=uniqueControl(root,"hang_id","End call","Hang up","End Call");
        if(button==null){say("Hang-up control not found. End the call inside Voice, then confirm Call ended here.");return;}
        commandBusy=true;boolean accepted=button.performAction(AccessibilityNodeInfo.ACTION_CLICK);handler.postDelayed(()->commandBusy=false,900);
        say(accepted?"Hang-up requested. Confirm Call ended once Voice ends the call.":"Hang-up failed. End the call inside Voice.");
    }
    private void confirmEnded(){
        AccessibilityNodeInfo root=voiceRoot();
        if(root!=null&&uniqueControl(root,"hang_id","End call","Hang up")!=null){say("Voice still shows an End call control. End the call before confirming.");return;}
        db.prefs.edit().putBoolean("call_unresolved",false).commit();say("Marked ended by you · save the call result");
    }
    private void manual(){Store.Lead l=db.current();if(l==null||l.dnc||db.activeLead()>0)return;db.attempt(l.id,"Manual call started");db.prefs.edit().putBoolean("call_unresolved",true).commit();say("Manual call logged · use Hang up or end in Voice");}
    private void say(String s){message=s;render();}
    private void move(int n){if(commandBusy){Ui.toast(this,"Finish or cancel the pending preparation first");return;}if(!canChangeLead())return;if(db.move(n)==null){say(n>0?"End of queue":"Start of queue");return;}stage=0;prepare();}
    public void render(){
        remove();shell=Ui.column(this);shell.setBackground(Ui.bg(Ui.BG,Ui.dp(this,18)));shell.setElevation(Ui.dp(this,14));
        params=new WindowManager.LayoutParams(minimized?Ui.dp(this,126):Math.min(getResources().getDisplayMetrics().widthPixels-Ui.dp(this,16),Ui.dp(this,380)),-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;params.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-params.width,db.prefs.getInt("panel_x",8)));params.y=Math.min(Ui.dp(this,48),db.prefs.getInt("panel_y",48));
        TextView handle=Ui.text(this,minimized?"ORYNLO  ↗":"ORYNLO  /  VOICE DESK     ↕ drag",13,Ui.MUTED);handle.setMinHeight(Ui.dp(this,40));shell.addView(handle);drag(handle);
        if(minimized){handle.setOnClickListener(v->{minimized=false;render();});wm.addView(shell,params);return;}
        Store.Lead l=db.current();if(l==null){shell.addView(Ui.text(this,"Add or import leads from Dashboard.",16,Ui.INK));}
        else{
            shell.addView(Ui.title(this,l.company));shell.addView(Ui.text(this,(l.owner==null?"":l.owner)+" · "+l.phone+"\n"+(l.trucks==null?"?":l.trucks)+" trucks · "+l.status,14,Ui.INK));
            shell.addView(Ui.text(this,message,12,Ui.MUTED));
            Ui.row(shell,Ui.button(this,"‹ Previous",()->move(-1)),Ui.button(this,"Next ›",()->move(1)));
            Ui.row(shell,Ui.button(this,"Prepare",this::prepare),Ui.button(this,"Call",this::call),Ui.button(this,"Hang up",this::hang));
            Ui.row(shell,Ui.button(this,"+ Result",this::result),Ui.button(this,"Script",this::script));
            if(navigationLocked())shell.addView(Ui.button(this,"Call ended — confirm",this::confirmEnded));
            else if(db.activeLead()==0)shell.addView(Ui.button(this,"Manual call started",this::manual));
            Ui.row(shell,Ui.button(this,"Copy",()->{((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Phone",l.phone));Ui.toast(this,"Number copied");}),Ui.button(this,"Minimize",()->{minimized=true;render();}));
        }
        shell.addView(Ui.button(this,"Inspect Voice controls",this::inspect));
        Ui.row(shell,Ui.button(this,"Dashboard",()->{startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP));hide();}),Ui.button(this,"Close panel",this::hide));
        wm.addView(shell,params);
    }
    private void result(){Store.Lead l=db.current();if(l==null)return;pendingLead=0;commandBusy=false;replaceBody(true);ScrollView scroll=new ScrollView(this);ResultForm form=new ResultForm(this,db,l,()->{message="Result saved · ready for Next";render();});scroll.addView(form.view);shell.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(Ui.dp(this,510),getResources().getDisplayMetrics().heightPixels/2)));shell.addView(Ui.button(this,"Back — keep draft",this::render));}
    private void script(){replaceBody(false);Playbook p=new Playbook(this);JSONObject item=p.stages.optJSONObject(stage);ScrollView scroll=new ScrollView(this);LinearLayout body=Ui.column(this);body.addView(Ui.text(this,item.optString("title"),14,Ui.MUTED));body.addView(Ui.text(this,p.personalize(item.optString("say"),db.current()),19,Ui.INK));body.addView(Ui.text(this,item.optString("coach"),13,Ui.MUTED));scroll.addView(body);shell.addView(scroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,240)));Ui.row(shell,Ui.button(this,"‹ Stage",()->{stage=Math.max(0,stage-1);script();}),Ui.button(this,"Stage ›",()->{stage=Math.min(p.stages.length()-1,stage+1);script();}));Ui.row(shell,Ui.button(this,"Objection",this::objections),Ui.button(this,"Controls",this::render));shell.addView(Ui.button(this,"Hang up",this::hang));}
    private void objections(){replaceBody(false);Playbook p=new Playbook(this);Spinner options=Ui.spinner(shell,"Quick objection",p.objectionNames(),"None");ScrollView scroll=new ScrollView(this);TextView response=Ui.text(this,"Select the objection",19,Ui.INK);scroll.addView(response);shell.addView(scroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,200)));options.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> a,View v,int n,long id){response.setText(p.personalize(p.response(Ui.value(options)),db.current()));}public void onNothingSelected(AdapterView<?>a){}});shell.addView(Ui.button(this,"Use this rebuttal",()->{Store.Lead l=db.current();if(l!=null)try{JSONObject draft=new JSONObject(db.prefs.getString("draft_"+l.id,"{}"));draft.put("objection",Ui.value(options));draft.put("score","Unscored");db.prefs.edit().putString("draft_"+l.id,draft.toString()).apply();Ui.toast(this,"Attached to this lead; rate it in + Result");}catch(Exception e){Ui.toast(this,"Could not save rebuttal");}}));Ui.row(shell,Ui.button(this,"Script",this::script),Ui.button(this,"Controls",this::render));shell.addView(Ui.button(this,"Hang up",this::hang));}
    private void replaceBody(boolean focus){if(shell==null)render();shell.removeAllViews();params.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|(focus?0:WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);params.softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;wm.updateViewLayout(shell,params);}
    private void drag(View view){view.setOnTouchListener(new View.OnTouchListener(){float x,y;int startX,startY;boolean moved;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();startX=params.x;startY=params.y;moved=false;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=e.getRawX()-x,dy=e.getRawY()-y;if(Math.abs(dx)+Math.abs(dy)>12)moved=true;params.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-params.width,startX+(int)dx));params.y=Math.max(0,Math.min(getResources().getDisplayMetrics().heightPixels-Ui.dp(VoiceService.this,100),startY+(int)dy));wm.updateViewLayout(shell,params);return true;}if(e.getAction()==MotionEvent.ACTION_UP){db.prefs.edit().putInt("panel_x",params.x).putInt("panel_y",params.y).apply();if(!moved)v.performClick();return true;}return false;}});}
    private void inspect(){String info=diagnostics();replaceBody(false);ScrollView sc=new ScrollView(this);TextView t=Ui.text(this,info,13,Ui.INK);t.setTextIsSelectable(true);sc.addView(t);shell.addView(sc,new LinearLayout.LayoutParams(-1,Ui.dp(this,300)));shell.addView(Ui.button(this,"Back",this::render));}
    public String diagnostics(){AccessibilityNodeInfo root=voiceRoot();if(root==null)return "Open Google Voice on its dial pad first. No active Voice window found.";StringBuilder s=new StringBuilder("Visible Voice controls (text values omitted):\n");for(AccessibilityNodeInfo n:nodes(root))if(n.isVisibleToUser()&&(n.isEditable()||n.isClickable()))s.append(n.getClassName()).append(" | ").append(n.getViewIdResourceName()).append(" | editable=").append(n.isEditable()).append("\n");return s.toString();}
}
