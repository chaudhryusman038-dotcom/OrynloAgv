package com.orynlo.voicedesk;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import java.util.*;
import java.util.regex.*;
import org.json.JSONObject;

/**
 * Hybrid Orynlo cockpit for Google Voice.
 *
 * The overlay deliberately occupies only the lower part of the screen so the
 * Google Voice call surface stays visible above it. Google Voice itself still
 * owns the actual VoIP call; Orynlo uses Accessibility only for visible UI
 * navigation and verified controls.
 */
public class VoiceService extends AccessibilityService {
    public static final String VOICE="com.google.android.apps.googlevoice";
    public static VoiceService instance;

    private Store db;
    private Playbook playbook;
    private LiveCoach live;
    private WindowManager wm;
    private LinearLayout shell;
    private WindowManager.LayoutParams params;
    private final Handler handler=new Handler(Looper.getMainLooper());

    private int stage=0;
    private String mode="script", detectedObjection=null, liveText="", assistState="Live Assist off";
    private String callState="Ready", voiceStateLabel="Voice not visible", speakerState="Speaker unknown";
    private long pendingLead=0, prepareDeadline=0, lastAdvanceAt=0, queuedLead=0, pauseEndsAt=0, pausedRemaining=0;
    private boolean commandBusy=false, connected=false, preDial=false, postPause=false, noteEditing=false;
    private boolean callsTabAttempted=false, dialpadAttempted=false;
    private int backAttempts=0, speakerAttempts=0;
    private float dragDownRawX=0, dragDownRawY=0;
    private int dragStartX=0, dragStartY=0;
    private String pendingDisposition=null, transcriptWindow="";
    private TextToSpeech tts;
    private boolean ttsReady=false;

    private static final Pattern TIMER=Pattern.compile("(^|\\s)\\d{1,2}:\\d{2}($|\\s)");
    private static final Pattern EMAIL=Pattern.compile("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}",Pattern.CASE_INSENSITIVE);

    private enum VoiceState { NOT_VISIBLE, ACCOUNT_CHOOSER, PROFILE_MENU, ACTIVE_CALL, DIALPAD, HOME, UNKNOWN }

    @Override protected void onServiceConnected(){
        instance=this;
        db=new Store(this);
        playbook=new Playbook(this);
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        live=new LiveCoach(this,new LiveCoach.Listener(){
            public void onText(String t,boolean f){handleTranscript(t,f);}
            public void onState(String s){assistState=s;refresh();}
        });
        tts=new TextToSpeech(this,status->{
            if(status==TextToSpeech.SUCCESS){
                int r=tts.setLanguage(Locale.US);
                ttsReady=r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(.90f);tts.setPitch(1.0f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                    @Override public void onStart(String id){}
                    @Override public void onError(String id){if(id!=null&&id.startsWith("owner:"))handler.post(()->beginDialAfterIntro(queuedLead));}
                    @Override public void onDone(String id){if(id!=null&&id.startsWith("owner:"))handler.postDelayed(()->beginDialAfterIntro(queuedLead),220);}
                });
            }
        });
        if(db.prefs.getBoolean("panel",false))show();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null)return;
        CharSequence p=event.getPackageName();
        if(p!=null&&VOICE.contentEquals(p.toString())){
            AccessibilityNodeInfo root=voiceRoot();
            updateVoiceState(root);
            if(pendingLead!=0)handler.postDelayed(this::tryStartCall,120);
            inspectCallState();
        }
    }

    @Override public void onInterrupt(){commandBusy=false;callState="Accessibility interrupted";refresh();}
    @Override public void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        if(live!=null)live.stop();
        if(tts!=null){try{tts.stop();tts.shutdown();}catch(Exception ignored){}}
        remove();instance=null;if(db!=null)db.close();super.onDestroy();
    }

    public void show(){db.prefs.edit().putBoolean("panel",true).apply();render();}
    public void hide(){db.prefs.edit().putBoolean("panel",false).apply();if(live!=null)live.stop();remove();}
    private void remove(){if(shell!=null){try{wm.removeView(shell);}catch(Exception ignored){}shell=null;}}
    private void refresh(){if(shell!=null)handler.post(this::render);}

    private AccessibilityNodeInfo voiceRoot(){
        AccessibilityNodeInfo r=getRootInActiveWindow();
        if(r!=null&&VOICE.contentEquals(pkg(r)))return r;
        for(AccessibilityWindowInfo w:getWindows())if(w.getType()==AccessibilityWindowInfo.TYPE_APPLICATION){
            r=w.getRoot();if(r!=null&&VOICE.contentEquals(pkg(r)))return r;
        }
        return null;
    }
    private String pkg(AccessibilityNodeInfo n){return n.getPackageName()==null?"":n.getPackageName().toString();}
    private List<AccessibilityNodeInfo> nodes(AccessibilityNodeInfo root){
        ArrayList<AccessibilityNodeInfo> out=new ArrayList<>();if(root==null)return out;
        ArrayDeque<AccessibilityNodeInfo> q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()&&out.size()<900){AccessibilityNodeInfo n=q.remove();out.add(n);for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}
        return out;
    }
    private String label(AccessibilityNodeInfo n){
        String a=n.getContentDescription()!=null?n.getContentDescription().toString():"";
        String b=n.getText()!=null?n.getText().toString():"";
        return (a+" "+b).trim();
    }
    private AccessibilityNodeInfo clickable(AccessibilityNodeInfo n){
        AccessibilityNodeInfo t=n;for(int i=0;i<5&&t!=null&&!t.isClickable();i++)t=t.getParent();
        return t!=null&&t.isClickable()?t:null;
    }
    private AccessibilityNodeInfo byConfiguredId(AccessibilityNodeInfo root,String pref){
        String configured=db.prefs.getString(pref,"").trim();if(configured.isEmpty())return null;
        ArrayList<AccessibilityNodeInfo> found=new ArrayList<>();
        for(AccessibilityNodeInfo n:nodes(root))if(n.isEnabled()&&configured.equals(n.getViewIdResourceName())){AccessibilityNodeInfo c=clickable(n);if(c!=null&&!found.contains(c))found.add(c);}
        return found.size()==1?found.get(0):null;
    }
    private AccessibilityNodeInfo uniqueControl(AccessibilityNodeInfo root,String pref,String... accepted){
        AccessibilityNodeInfo configured=byConfiguredId(root,pref);if(configured!=null)return configured;
        ArrayList<AccessibilityNodeInfo> m=new ArrayList<>();
        for(AccessibilityNodeInfo n:nodes(root))if(n.isEnabled()){
            String l=label(n).trim();boolean ok=Arrays.stream(accepted).anyMatch(a->a.equalsIgnoreCase(l));
            if(ok){AccessibilityNodeInfo c=clickable(n);if(c!=null&&!m.contains(c))m.add(c);}
        }
        return m.size()==1?m.get(0):null;
    }
    private AccessibilityNodeInfo containsControl(AccessibilityNodeInfo root,String... accepted){
        ArrayList<AccessibilityNodeInfo> m=new ArrayList<>();
        for(AccessibilityNodeInfo n:nodes(root))if(n.isEnabled()){
            String l=label(n).toLowerCase(Locale.US);boolean ok=Arrays.stream(accepted).anyMatch(a->l.contains(a.toLowerCase(Locale.US)));
            if(ok){AccessibilityNodeInfo c=clickable(n);if(c!=null&&!m.contains(c))m.add(c);}
        }
        return m.size()==1?m.get(0):null;
    }
    private AccessibilityNodeInfo numberField(AccessibilityNodeInfo root,String phone){
        String configured=db.prefs.getString("number_id","").trim();ArrayList<AccessibilityNodeInfo> result=new ArrayList<>();
        for(AccessibilityNodeInfo n:nodes(root))if(n.isEnabled()&&n.isEditable()){
            String hint=n.getHintText()==null?"":n.getHintText().toString();String d=(label(n)+" "+hint).toLowerCase(Locale.US);
            boolean isPhone=(n.getInputType()&android.text.InputType.TYPE_MASK_CLASS)==android.text.InputType.TYPE_CLASS_PHONE;
            boolean same=phone!=null&&!phone.isEmpty()&&phone.equals(Csv.phone(n.getText()==null?"":n.getText().toString()));
            if(!configured.isEmpty()?configured.equals(n.getViewIdResourceName()):isPhone||same||d.contains("phone number")||d.contains("enter a number")||d.contains("name or number")||d.contains("number to call"))result.add(n);
        }
        return result.size()==1?result.get(0):null;
    }
    private String snapshot(AccessibilityNodeInfo root){StringBuilder s=new StringBuilder();for(AccessibilityNodeInfo n:nodes(root)){String l=label(n);if(!l.isEmpty())s.append(l).append(' ');}return s.toString();}

    private boolean hasExactLabel(AccessibilityNodeInfo root,String... labels){
        for(AccessibilityNodeInfo n:nodes(root)){
            if(!n.isEnabled())continue;String l=label(n).trim();
            for(String wanted:labels)if(wanted.equalsIgnoreCase(l))return true;
        }
        return false;
    }
    private boolean hasExactCallDuration(AccessibilityNodeInfo root){
        for(AccessibilityNodeInfo n:nodes(root)){
            String l=label(n).trim();
            // Important: exact duration only. History timestamps such as "2:31 AM" must never count as an active call.
            if(l.matches("\\d{1,2}:\\d{2}"))return true;
        }
        return false;
    }
    private boolean isVerifiedActiveCall(AccessibilityNodeInfo root,String snapshot){
        AccessibilityNodeInfo hang=uniqueControl(root,"hang_id","End call","Hang up","End Call");
        if(hang==null)hang=containsControl(root,"end call","hang up");
        if(hang!=null)return true;
        boolean mute=hasExactLabel(root,"Mute","Unmute");
        boolean speaker=hasExactLabel(root,"Speaker","Speakerphone","Turn speaker on","Turn speaker off");
        boolean keypad=hasExactLabel(root,"Keypad","Dialpad","Dial pad");
        boolean hold=hasExactLabel(root,"Hold","Resume call");
        int callControls=(mute?1:0)+(speaker?1:0)+(keypad?1:0)+(hold?1:0);
        boolean callWording=snapshot.contains("call in progress")||snapshot.contains("dialing")||snapshot.contains("connecting")||snapshot.contains("calling…")||snapshot.contains("calling...");
        // Active call requires real call controls. A time-looking string by itself is never enough.
        return callControls>=3||(callControls>=2&&(hasExactCallDuration(root)||callWording));
    }
    private VoiceState detectVoiceState(AccessibilityNodeInfo root){
        if(root==null)return VoiceState.NOT_VISIBLE;
        String s=snapshot(root).toLowerCase(Locale.US);
        if(isAccountChooser(s))return VoiceState.ACCOUNT_CHOOSER;
        if(numberField(root,"")!=null||s.contains("enter a name or number")||s.contains("enter a number")||s.contains("dial pad")||s.contains("dialpad"))return VoiceState.DIALPAD;
        if(isVerifiedActiveCall(root,s))return VoiceState.ACTIVE_CALL;
        if(isProfileMenu(s))return VoiceState.PROFILE_MENU;
        if(s.contains("search google voice")||s.contains("calls")||s.contains("messages")||s.contains("voicemail")||s.contains("make a call")||s.contains("new call"))return VoiceState.HOME;
        return VoiceState.UNKNOWN;
    }
    private boolean isAccountChooser(String s){return (s.contains("choose an account")||s.contains("select an account")||s.contains("use voice with")||s.contains("choose account"))&&s.contains("account");}
    private boolean isProfileMenu(String s){
        int score=0;if(s.contains("settings"))score++;if(s.contains("help & feedback"))score++;if(s.contains("manage accounts"))score++;if(s.contains("voice number"))score++;if(s.contains("sign out"))score++;
        return score>=2;
    }
    private void updateVoiceState(AccessibilityNodeInfo root){
        VoiceState st=detectVoiceState(root);
        switch(st){
            case ACCOUNT_CHOOSER: voiceStateLabel="Account chooser";break;
            case PROFILE_MENU: voiceStateLabel="Profile / menu";break;
            case ACTIVE_CALL: voiceStateLabel="Active call";break;
            case DIALPAD: voiceStateLabel="Dialpad";break;
            case HOME: voiceStateLabel="Voice home";break;
            case UNKNOWN: voiceStateLabel="Voice screen detected";break;
            default: voiceStateLabel="Voice not visible";
        }
    }

    /** Find Google Voice's global dial launcher. The floating action button can sit underneath our overlay,
     * so text-only matching is not enough. As a last resort, use the bottom-area Call/FAB control and
     * never choose call-history row icons from the upper half of the screen. */
    private AccessibilityNodeInfo dialLauncherControl(AccessibilityNodeInfo root){
        AccessibilityNodeInfo dial=byConfiguredId(root,"dialpad_id");
        if(dial!=null)return dial;
        dial=uniqueControl(root,"dialpad_id","Make a call","Start a call","New call","Dialpad","Dial pad","Call a number");
        if(dial==null)dial=containsControl(root,"make a call","start a call","new call","dial pad","dialpad","call a number");
        if(dial!=null)return dial;

        int screenH=getResources().getDisplayMetrics().heightPixels;
        AccessibilityNodeInfo best=null;int bestY=-1,bestX=-1;
        for(AccessibilityNodeInfo n:nodes(root)){
            if(!n.isEnabled())continue;AccessibilityNodeInfo c=clickable(n);if(c==null)continue;
            String l=label(n).trim().toLowerCase(Locale.US);
            String id=n.getViewIdResourceName()==null?"":n.getViewIdResourceName().toLowerCase(Locale.US);
            boolean callish=l.equals("call")||l.equals("make a call")||l.equals("start a call")||l.equals("new call")||id.contains("dialpad")||id.contains("dial_pad")||id.contains("make_call")||id.contains("call_fab")||id.endsWith(":id/fab");
            if(!callish)continue;Rect r=new Rect();c.getBoundsInScreen(r);
            // History-row phone icons in Voice live in the upper list. The global dial FAB lives near the bottom.
            if(r.centerY()<screenH*0.58f)continue;
            if(r.centerY()>bestY||(r.centerY()==bestY&&r.centerX()>bestX)){best=c;bestY=r.centerY();bestX=r.centerX();}
        }
        return best;
    }

    /** Only select an account when Google Voice is actually displaying an account chooser. */
    private boolean maybeSelectAccount(AccessibilityNodeInfo root){
        if(detectVoiceState(root)!=VoiceState.ACCOUNT_CHOOSER)return false;
        String wanted=db.prefs.getString("voice_account","").trim();
        ArrayList<AccessibilityNodeInfo> matches=new ArrayList<>(), emails=new ArrayList<>();
        for(AccessibilityNodeInfo n:nodes(root)){
            if(!n.isVisibleToUser())continue;String l=label(n).trim();if(l.isEmpty())continue;AccessibilityNodeInfo c=clickable(n);if(c==null)continue;
            if(!wanted.isEmpty()&&l.toLowerCase(Locale.US).contains(wanted.toLowerCase(Locale.US))&&!matches.contains(c))matches.add(c);
            if(EMAIL.matcher(l).find()&&!emails.contains(c))emails.add(c);
        }
        AccessibilityNodeInfo target=matches.size()==1?matches.get(0):(wanted.isEmpty()&&emails.size()==1?emails.get(0):null);
        if(target!=null&&target.performAction(AccessibilityNodeInfo.ACTION_CLICK)){callState="Voice account selected";return true;}
        callState=wanted.isEmpty()?"Voice account chooser visible · choose the account once in the Voice area above":"Saved Voice account was not uniquely visible";
        return false;
    }

    private void openVoice(){
        Intent launch=getPackageManager().getLaunchIntentForPackage(VOICE);
        if(launch==null){callState="Google Voice is not installed";refresh();return;}
        try{startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));callState="Opening Google Voice…";}catch(Exception e){callState="Could not open Google Voice";}
        refresh();
    }

    /** Initial CALL button. Every later call can start automatically after the note window. */
    private void call(){
        if(commandBusy||preDial||postPause)return;
        if(db.prefs.getBoolean("call_unresolved",false)){callState="A call is already active · use HANG UP";refresh();return;}
        Store.Lead lead=db.current();if(lead==null){Ui.toast(this,"Import or add leads first");return;}if(lead.dnc){callState="Do not call: blocked lead";refresh();return;}
        if(db.activeLead()>0)db.defaultPendingNoAnswer();
        announceOwnerThenDial(lead);
    }

    private void announceOwnerThenDial(Store.Lead lead){
        if(lead==null||lead.dnc)return;
        queuedLead=lead.id;preDial=true;stage=0;mode="script";detectedObjection=null;liveText="";transcriptWindow="";pendingDisposition=null;connected=false;
        String first=firstName(lead.owner);callState=first.isEmpty()?"Contact ready · owner name unavailable · dialing next":"Contact ready · listen: "+first+" · "+first;render();
        if(!first.isEmpty()&&ttsReady&&tts!=null){
            try{tts.speak(first+". "+first+".",TextToSpeech.QUEUE_FLUSH,null,"owner:"+lead.id+":"+System.currentTimeMillis());handler.postDelayed(()->beginDialAfterIntro(lead.id),4200);return;}catch(Exception ignored){}
        }
        handler.postDelayed(()->beginDialAfterIntro(lead.id),first.isEmpty()?900:1400);
    }
    private String firstName(String owner){if(owner==null)return "";String s=owner.trim();if(s.isEmpty())return "";return s.split("\\s+")[0];}

    private void beginDialAfterIntro(long leadId){
        if(!preDial||queuedLead!=leadId)return;preDial=false;Store.Lead lead=db.lead(leadId);if(lead==null||lead.dnc)return;
        pendingLead=lead.id;prepareDeadline=System.currentTimeMillis()+18000;commandBusy=true;dialpadAttempted=false;callsTabAttempted=false;backAttempts=0;
        callState="Opening Voice · automation will follow the visible Voice state";render();openVoice();handler.postDelayed(this::tryStartCall,550);
    }

    /** State-machine navigation for Google Voice instead of generic blind clicking. */
    private void tryStartCall(){
        if(pendingLead==0)return;
        Store.Lead lead=db.lead(pendingLead);if(lead==null||lead.dnc){pendingLead=0;commandBusy=false;return;}
        AccessibilityNodeInfo root=voiceRoot();VoiceState state=detectVoiceState(root);updateVoiceState(root);

        if(state==VoiceState.NOT_VISIBLE){
            if(System.currentTimeMillis()<prepareDeadline){openVoice();handler.postDelayed(this::tryStartCall,650);return;}
            failDial("Google Voice never became visible");return;
        }
        if(state==VoiceState.ACCOUNT_CHOOSER){
            boolean selected=maybeSelectAccount(root);
            if(selected){handler.postDelayed(this::tryStartCall,650);return;}
            if(System.currentTimeMillis()<prepareDeadline){handler.postDelayed(this::tryStartCall,900);return;}
            failDial("Choose the Voice account in the visible area above, then tap FIX VOICE");return;
        }
        if(state==VoiceState.PROFILE_MENU){
            if(backAttempts<3){backAttempts++;performGlobalAction(GLOBAL_ACTION_BACK);callState="Voice profile/menu detected · going back to Calls";refresh();handler.postDelayed(this::tryStartCall,550);return;}
            failDial("Voice stayed in profile/menu. Tap FIX VOICE after the Calls screen appears");return;
        }
        if(state==VoiceState.ACTIVE_CALL){
            failDial("Verified Google Voice active-call controls are already on screen");return;
        }

        AccessibilityNodeInfo field=numberField(root,lead.phone);
        if(state==VoiceState.DIALPAD||field!=null){
            if(field==null){
                if(System.currentTimeMillis()<prepareDeadline){handler.postDelayed(this::tryStartCall,350);return;}
                failDial("Dialpad opened but number field was not found");return;
            }
            String current=field.getText()==null?"":field.getText().toString();
            if(!lead.phone.equals(Csv.phone(current))){
                Bundle a=new Bundle();a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,lead.phone);
                boolean set=field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,a);
                callState=set?"Number entered · waiting for verified Call button":"Voice refused number entry";refresh();handler.postDelayed(this::tryStartCall,350);return;
            }
            AccessibilityNodeInfo button=uniqueControl(root,"call_id","Call","Place call","Call "+lead.phone);
            if(button==null)button=containsControl(root,"call "+lead.phone,"place call");
            if(button!=null){
                boolean ok=button.performAction(AccessibilityNodeInfo.ACTION_CLICK);pendingLead=0;commandBusy=false;
                if(ok){
                    db.attempt(lead.id,"Dial requested");db.prefs.edit().putBoolean("call_unresolved",true).commit();connected=false;callState="Dial requested · Voice call area stays visible above";
                    startAssistIfEnabled();speakerAttempts=0;if(db.prefs.getBoolean("auto_speaker",true))handler.postDelayed(this::ensureSpeakerOn,900);render();
                }else{callState="Voice did not accept Call";refresh();}
                return;
            }
            if(System.currentTimeMillis()<prepareDeadline){callState="Number ready · waiting for Voice Call control";refresh();handler.postDelayed(this::tryStartCall,400);return;}
            failDial("Number was entered but Call control was not found");return;
        }

        if(state==VoiceState.HOME||state==VoiceState.UNKNOWN){
            AccessibilityNodeInfo dial=dialLauncherControl(root);
            if(dial!=null&&!dialpadAttempted){
                boolean clicked=dial.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                dialpadAttempted=clicked;callState=clicked?"Voice home verified · opening dialpad":"Found Voice dial control but click was rejected";refresh();
                handler.postDelayed(this::tryStartCall,600);return;
            }

            AccessibilityNodeInfo calls=uniqueControl(root,"calls_tab_id","Calls");
            if(calls!=null&&!callsTabAttempted){callsTabAttempted=true;calls.performAction(AccessibilityNodeInfo.ACTION_CLICK);callState="Opening Voice Calls tab";refresh();handler.postDelayed(this::tryStartCall,600);return;}

            if(state==VoiceState.UNKNOWN&&backAttempts<2){backAttempts++;performGlobalAction(GLOBAL_ACTION_BACK);callState="Unknown Voice screen · backing out once";refresh();handler.postDelayed(this::tryStartCall,550);return;}
        }

        if(System.currentTimeMillis()<prepareDeadline){handler.postDelayed(this::tryStartCall,450);return;}
        failDial("Could not reach Voice dialpad. The visible Voice area shows where it stopped");
    }

    private void failDial(String reason){pendingLead=0;commandBusy=false;callState=reason;refresh();}

    /** Manual rescue: bring Voice forward and continue the state machine from whatever is visible. */
    private void fixVoice(){
        Store.Lead lead=db.current();if(lead==null){Ui.toast(this,"No lead selected");return;}
        if(db.prefs.getBoolean("call_unresolved",false)){callState="Active call detected · FIX VOICE will not redial";openVoice();return;}
        pendingLead=lead.id;prepareDeadline=System.currentTimeMillis()+18000;commandBusy=true;dialpadAttempted=false;callsTabAttempted=false;backAttempts=0;callState="Repairing Google Voice flow…";openVoice();handler.postDelayed(this::tryStartCall,500);
    }

    /** Manual call-end only. */
    private void hang(){
        if(commandBusy||postPause)return;
        if(!db.prefs.getBoolean("call_unresolved",false)){callState="No active call";refresh();return;}
        AccessibilityNodeInfo root=voiceRoot();AccessibilityNodeInfo b=uniqueControl(root,"hang_id","End call","Hang up","End Call");if(b==null)b=containsControl(root,"end call","hang up");
        if(b==null){callState="Voice Hang up control not found · look at the Voice area above or tap FIX VOICE";refresh();return;}
        commandBusy=true;boolean ok=b.performAction(AccessibilityNodeInfo.ACTION_CLICK);callState=ok?"Hang-up requested":"Voice did not accept Hang up";
        handler.postDelayed(()->{commandBusy=false;if(ok)finishManualEnd();},700);refresh();
    }
    private void finishManualEnd(){db.prefs.edit().putBoolean("call_unresolved",false).commit();if(live!=null)live.stop();assistState="Live Assist off";connected=false;speakerState="Speaker unknown";startPostCallPause();}

    /** Toggle Google Voice's visible Speaker control. */
    private void toggleSpeaker(){
        AccessibilityNodeInfo root=voiceRoot();if(root==null){callState="Open Google Voice first";refresh();return;}
        AccessibilityNodeInfo b=speakerControl(root);if(b==null){callState="Speaker control not found on this Voice screen";speakerState="Speaker unavailable";refresh();return;}
        boolean ok=b.performAction(AccessibilityNodeInfo.ACTION_CLICK);speakerState=ok?"Speaker toggled":"Speaker toggle failed";callState=speakerState;refresh();
    }
    private AccessibilityNodeInfo speakerControl(AccessibilityNodeInfo root){
        AccessibilityNodeInfo configured=byConfiguredId(root,"speaker_id");if(configured!=null)return configured;
        AccessibilityNodeInfo b=uniqueControl(root,"speaker_id","Speaker","Speakerphone","Turn speaker on","Turn speaker off");
        if(b==null)b=containsControl(root,"speakerphone","turn speaker on","turn speaker off");
        return b;
    }
    private boolean speakerAppearsOn(AccessibilityNodeInfo b){
        if(b==null)return false;String l=label(b).toLowerCase(Locale.US);return b.isChecked()||b.isSelected()||l.contains("turn speaker off")||l.contains("speaker on");
    }
    private void ensureSpeakerOn(){
        if(!db.prefs.getBoolean("call_unresolved",false)||!db.prefs.getBoolean("auto_speaker",true))return;
        AccessibilityNodeInfo root=voiceRoot();VoiceState st=detectVoiceState(root);updateVoiceState(root);AccessibilityNodeInfo b=speakerControl(root);
        if(b!=null){
            if(speakerAppearsOn(b)){speakerState="Speaker on";refresh();return;}
            if(b.performAction(AccessibilityNodeInfo.ACTION_CLICK)){speakerState="Speaker requested";callState="Speaker requested in Google Voice";refresh();return;}
        }
        if(speakerAttempts++<8)handler.postDelayed(this::ensureSpeakerOn,650);else{speakerState="Speaker control not found";refresh();}
    }

    /** Inspect visible state for coaching only; never auto-end a call. */
    private void inspectCallState(){
        AccessibilityNodeInfo root=voiceRoot();updateVoiceState(root);
        if(!db.prefs.getBoolean("call_unresolved",false)||root==null)return;
        String snap=snapshot(root).toLowerCase(Locale.US);
        if(TIMER.matcher(" "+snap+" ").find()||snap.contains("connected")||detectVoiceState(root)==VoiceState.ACTIVE_CALL){
            if(!connected){connected=true;callState="Voice call screen detected · script tracking active";if(db.prefs.getBoolean("auto_speaker",true))handler.postDelayed(this::ensureSpeakerOn,350);refresh();}
        }
    }

    private void startPostCallPause(){
        postPause=true;noteEditing=false;int sec=Math.max(2,Math.min(60,db.prefs.getInt("post_call_seconds",8)));pauseEndsAt=System.currentTimeMillis()+sec*1000L;callState="Call ended · optional note window";render();handler.removeCallbacks(postPauseTick);handler.post(postPauseTick);
    }
    private final Runnable postPauseTick=new Runnable(){public void run(){if(!postPause||noteEditing)return;long left=Math.max(0,pauseEndsAt-System.currentTimeMillis());if(left<=0){finishPostCallAndDialNext();return;}callState="Optional note · next call auto-starts in "+Math.max(1,(left+999)/1000)+"s";render();handler.postDelayed(this,1000);}};
    private void openQuickNote(){if(!postPause||noteEditing)return;noteEditing=true;pausedRemaining=Math.max(2000,pauseEndsAt-System.currentTimeMillis());handler.removeCallbacks(postPauseTick);remove();Intent i=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("quick_note",true);startActivity(i);}
    public void resumeAfterNote(){if(!postPause)return;noteEditing=false;pauseEndsAt=System.currentTimeMillis()+Math.max(2000,pausedRemaining);show();handler.removeCallbacks(postPauseTick);handler.post(postPauseTick);}
    private void finishPostCallAndDialNext(){
        if(!postPause)return;postPause=false;noteEditing=false;handler.removeCallbacks(postPauseTick);
        if(db.activeLead()>0){if(pendingDisposition!=null)db.autoFinish(pendingDisposition,"Detected during call by Live Assist");else db.defaultPendingNoAnswer();}
        pendingDisposition=null;detectedObjection=null;liveText="";transcriptWindow="";Store.Lead next=db.move(1);stage=0;mode="script";
        if(next==null){callState="Queue complete · no next callable lead";render();return;}
        callState="Next contact loaded";render();handler.postDelayed(()->announceOwnerThenDial(next),500);
    }

    private void startAssistIfEnabled(){if(live==null)return;if(db.prefs.getBoolean("live_assist",false)){live.start();if(!live.supported())assistState="Live Assist may be blocked during VoIP on this device";}else assistState="Live Assist off";}
    private void handleTranscript(String text,boolean fin){
        if(text==null||text.trim().isEmpty())return;liveText=text;transcriptWindow=(transcriptWindow+" "+text).trim();if(transcriptWindow.length()>650)transcriptWindow=transcriptWindow.substring(transcriptWindow.length()-650);
        String machine=playbook.machineDisposition(transcriptWindow);if(machine!=null&&db.prefs.getBoolean("call_unresolved",false)){pendingDisposition=machine;callState=machine+" detected · use HANG UP when you want to end the call";refresh();return;}
        String objection=playbook.matchObjection(transcriptWindow);if(objection!=null){detectedObjection=objection;mode="objection";callState="Objection match · rebuttal ready";render();return;}
        if(fin&&mode.equals("script")&&System.currentTimeMillis()-lastAdvanceAt>1800&&playbook.stageSpoken(stage,transcriptWindow)){if(stage<playbook.stages.length()-1){stage++;lastAdvanceAt=System.currentTimeMillis();callState="Stage auto-tracked";render();}}else refresh();
    }

    public void render(){
        remove();shell=Ui.column(this);shell.setBackgroundColor(Ui.BG);shell.setPadding(Ui.dp(this,12),Ui.dp(this,6),Ui.dp(this,12),Ui.dp(this,8));
        params=panelLayoutParams();
        Store.Lead lead=db.current();

        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        TextView h=Ui.text(this,"ORYNLO  ·  DRAG THIS BAR",12,Ui.CYAN);h.setTypeface(null,android.graphics.Typeface.BOLD);
        h.setPadding(Ui.dp(this,4),Ui.dp(this,8),Ui.dp(this,4),Ui.dp(this,8));
        h.setOnTouchListener(this::dragPanel);
        header.addView(h,new LinearLayout.LayoutParams(0,-2,1));
        Button smaller=Ui.buttonColor(this,"−",Ui.CARD,()->resizePanel(-1));header.addView(smaller,new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,44)));
        Button larger=Ui.buttonColor(this,"+",Ui.CARD,()->resizePanel(1));header.addView(larger,new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,44)));
        Button x=Ui.buttonColor(this,"×",Ui.CARD,this::hide);header.addView(x,new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,44)));shell.addView(header);

        renderContact(shell,lead);
        LinearLayout status=Ui.card(shell);status.addView(Ui.text(this,"VOICE: "+voiceStateLabel+"   ·   "+speakerState,12,Ui.GREEN));status.addView(Ui.text(this,callState+(liveText.isEmpty()?"":"  ·  Heard: “"+ellipsize(liveText,42)+"”"),11,Ui.MUTED));

        if(postPause){renderPause(shell,lead);Ui.row(shell,Ui.buttonColor(this,"VOICE",Ui.CARD,this::openVoice),Ui.buttonColor(this,"SPEAKER",Ui.BLUE,this::toggleSpeaker));wm.addView(shell,params);return;}

        ScrollView sc=new ScrollView(this);LinearLayout body=Ui.column(this);sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        if(mode.equals("objection"))renderObjection(body,detectedObjection);else if(mode.equals("objection_list"))renderObjectionList(body);else renderScript(body);
        Ui.row(shell,Ui.buttonColor(this,"‹ SCRIPT",Ui.CARD,()->{stage=Math.max(0,stage-1);mode="script";render();}),Ui.buttonColor(this,"SCRIPT ›",Ui.CARD,()->{stage=Math.min(playbook.stages.length()-1,stage+1);mode="script";render();}),Ui.buttonColor(this,"OBJECTION",Ui.PURPLE,()->{mode="objection_list";render();}));
        Ui.row(shell,Ui.buttonColor(this,"CALL",Ui.GREEN,this::call),Ui.buttonColor(this,"HANG UP",Ui.RED,this::hang),Ui.buttonColor(this,"SPEAKER",Ui.BLUE,this::toggleSpeaker));
        Ui.row(shell,Ui.buttonColor(this,"FIX VOICE",Ui.AMBER,this::fixVoice),Ui.buttonColor(this,"OPEN VOICE",Ui.CARD,this::openVoice));
        wm.addView(shell,params);
    }

    private WindowManager.LayoutParams panelLayoutParams(){
        int level=Math.max(0,Math.min(4,db.prefs.getInt("panel_size_level",2)));
        int[] widths={68,80,92,96,100};
        int[] heights={36,46,58,68,78};
        int screenW=getResources().getDisplayMetrics().widthPixels;
        int screenH=getResources().getDisplayMetrics().heightPixels;
        int width=Math.max(Ui.dp(this,280),Math.round(screenW*(widths[level]/100f)));
        int height=Math.max(Ui.dp(this,300),Math.round(screenH*(heights[level]/100f)));
        width=Math.min(screenW,width);height=Math.min(screenH,height);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(width,height,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.START;
        int savedX=db.prefs.getInt("panel_x",Math.max(0,(screenW-width)/2));
        int savedY=db.prefs.getInt("panel_y",Math.max(0,screenH-height));
        p.x=Math.max(0,Math.min(savedX,Math.max(0,screenW-width)));
        p.y=Math.max(0,Math.min(savedY,Math.max(0,screenH-height)));
        return p;
    }

    private boolean dragPanel(View v,MotionEvent e){
        if(params==null||shell==null)return false;
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            dragDownRawX=e.getRawX();dragDownRawY=e.getRawY();dragStartX=params.x;dragStartY=params.y;return true;
        }
        if(e.getAction()==MotionEvent.ACTION_MOVE){
            int screenW=getResources().getDisplayMetrics().widthPixels,screenH=getResources().getDisplayMetrics().heightPixels;
            int nx=dragStartX+Math.round(e.getRawX()-dragDownRawX),ny=dragStartY+Math.round(e.getRawY()-dragDownRawY);
            params.x=Math.max(0,Math.min(nx,Math.max(0,screenW-params.width)));
            params.y=Math.max(0,Math.min(ny,Math.max(0,screenH-params.height)));
            try{wm.updateViewLayout(shell,params);}catch(Exception ignored){}
            return true;
        }
        if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){
            db.prefs.edit().putInt("panel_x",params.x).putInt("panel_y",params.y).apply();return true;
        }
        return false;
    }

    private void resizePanel(int delta){
        int level=Math.max(0,Math.min(4,db.prefs.getInt("panel_size_level",2)+delta));
        db.prefs.edit().putInt("panel_size_level",level).apply();
        callState="Panel size "+(level+1)+"/5 · drag the top bar to move it";
        render();
    }

    private void renderContact(LinearLayout parent,Store.Lead l){
        LinearLayout c=Ui.card(parent);c.addView(Ui.label(this,"CONTACT",Ui.CYAN));if(l==null){c.addView(Ui.text(this,"No lead selected",16,Ui.MUTED));return;}
        String owner=(l.owner==null||l.owner.trim().isEmpty())?"Owner name not available":l.owner;String trucks=(l.trucks==null||l.trucks.trim().isEmpty())?"fleet size unknown":l.trucks+" trucks";
        c.addView(Ui.text(this,l.company,16,Ui.INK));
        c.addView(Ui.text(this,owner+"  ·  "+trucks,13,Ui.GREEN));
        TextView phone=Ui.text(this,"TAP TO COPY NUMBER   "+l.phone,14,Ui.CYAN);
        phone.setTypeface(null,android.graphics.Typeface.BOLD);
        phone.setPadding(Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8));
        phone.setBackground(Ui.bg(Ui.CARD,12));
        phone.setOnClickListener(v->copyPhone(l.phone));
        c.addView(phone);
        c.addView(Ui.text(this,"After copying, move/shrink Orynlo and paste the number into Google Voice yourself.",11,Ui.MUTED));
        String extra=((l.lanes==null?"":l.lanes.trim())+(l.email==null||l.email.trim().isEmpty()?"":"  ·  "+l.email)).trim();if(!extra.isEmpty())c.addView(Ui.text(this,extra,11,Ui.MUTED));
    }

    private void copyPhone(String phone){
        if(phone==null||phone.trim().isEmpty()){Ui.toast(this,"No phone number");return;}
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Orynlo phone",phone));
        callState="Number copied · paste it into Google Voice";
        Ui.toast(this,"Copied "+phone);
        refresh();
    }

    private void renderPause(LinearLayout parent,Store.Lead l){
        long left=Math.max(0,pauseEndsAt-System.currentTimeMillis());LinearLayout c=Ui.card(parent);c.addView(Ui.label(this,"POST-CALL PAUSE",Ui.AMBER));c.addView(Ui.text(this,"Next number auto-dials in "+Math.max(0,(left+999)/1000)+" seconds.",17,Ui.INK));c.addView(Ui.text(this,"No result selected = No answer. Note is optional.",12,Ui.MUTED));c.addView(Ui.buttonColor(this,"NOTE (OPTIONAL)",Ui.PURPLE,this::openQuickNote));if(pendingDisposition!=null)c.addView(Ui.text(this,"Pending disposition: "+pendingDisposition,13,Ui.AMBER));
    }
    private void renderScript(LinearLayout body){
        JSONObject s=playbook.stage(stage);body.addView(Ui.label(this,"HOW TO SAY IT",Ui.AMBER));body.addView(Ui.text(this,s.optString("style"),14,Ui.AMBER));body.addView(Ui.text(this,s.optString("energy"),13,Ui.GREEN));
        LinearLayout card=Ui.card(body);card.addView(Ui.label(this,s.optString("title")+"  ·  "+(stage+1)+"/"+playbook.stages.length(),Ui.CYAN));card.addView(Ui.speech(this,playbook.personalize(s.optString("say"),db.current())));
        body.addView(Ui.label(this,"UNDERSTAND — DO NOT READ",Ui.MUTED));body.addView(Ui.text(this,s.optString("coach"),12,Ui.MUTED));
        if(db.prefs.getBoolean("live_assist",false))body.addView(Ui.text(this,"Live Assist: "+assistState,11,Ui.PURPLE));
    }
    private void renderObjection(LinearLayout body,String name){
        JSONObject o=playbook.objection(name);if(o==null){mode="objection_list";renderObjectionList(body);return;}
        body.addView(Ui.label(this,"COACH FIRST — READ SILENTLY",Ui.PURPLE));body.addView(Ui.text(this,o.optString("cue"),15,Ui.PURPLE));body.addView(Ui.label(this,"HOW TO SAY IT",Ui.AMBER));body.addView(Ui.text(this,o.optString("style"),14,Ui.AMBER));body.addView(Ui.text(this,o.optString("energy"),13,Ui.GREEN));
        LinearLayout card=Ui.card(body);card.addView(Ui.label(this,o.optString("title"),Ui.RED));card.addView(Ui.speech(this,playbook.personalize(o.optString("say"),db.current())));body.addView(Ui.buttonColor(this,"BACK TO SCRIPT",Ui.CARD,()->{mode="script";render();}));
    }
    private void renderObjectionList(LinearLayout body){body.addView(Ui.label(this,"TAP WHAT YOU HEARD",Ui.PURPLE));body.addView(Ui.text(this,"Manual rebuttals are local/offline. Live Assist opens the same rebuttal when Android returns a matching transcript.",12,Ui.MUTED));for(String n:playbook.objectionNames())if(!n.equals("None"))body.addView(Ui.buttonColor(this,n,Ui.CARD,()->{detectedObjection=n;mode="objection";render();}));}
    private String ellipsize(String s,int n){return s.length()<=n?s:s.substring(0,n-1)+"…";}
}
