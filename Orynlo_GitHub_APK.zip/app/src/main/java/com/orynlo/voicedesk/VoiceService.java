package com.orynlo.voicedesk;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import java.util.*;
import java.util.regex.*;
import org.json.JSONObject;

/** Full-screen automation cockpit layered over Google Voice. */
public class VoiceService extends AccessibilityService {
    public static final String VOICE="com.google.android.apps.googlevoice";
    public static VoiceService instance;
    private Store db; private Playbook playbook; private LiveCoach live;
    private WindowManager wm; private LinearLayout shell; private WindowManager.LayoutParams params;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int stage=0; private String mode="script", detectedObjection=null, liveText="", assistState="Live Assist off", callState="Ready";
    private long pendingLead=0, prepareDeadline=0, callRequestedAt=0, lastAdvanceAt=0, queuedLead=0, pauseEndsAt=0, pausedRemaining=0;
    private boolean commandBusy=false, dialpadAttempted=false, connected=false, preDial=false, postPause=false, noteEditing=false;
    private String pendingDisposition=null, transcriptWindow="";
    private TextToSpeech tts; private boolean ttsReady=false;
    private static final Pattern TIMER=Pattern.compile("(^|\\s)\\d{1,2}:\\d{2}($|\\s)");

    @Override protected void onServiceConnected(){
        instance=this;db=new Store(this);playbook=new Playbook(this);wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        live=new LiveCoach(this,new LiveCoach.Listener(){public void onText(String t,boolean f){handleTranscript(t,f);}public void onState(String s){assistState=s;refresh();}});
        tts=new TextToSpeech(this,status->{
            if(status==TextToSpeech.SUCCESS){int r=tts.setLanguage(Locale.US);ttsReady=r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED;tts.setSpeechRate(.90f);tts.setPitch(1.0f);tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                @Override public void onStart(String id){}
                @Override public void onError(String id){if(id!=null&&id.startsWith("owner:"))handler.post(()->beginDialAfterIntro(queuedLead));}
                @Override public void onDone(String id){if(id!=null&&id.startsWith("owner:"))handler.postDelayed(()->beginDialAfterIntro(queuedLead),220);}
            });}
        });
        if(db.prefs.getBoolean("panel",false))show();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){if(event==null)return;CharSequence p=event.getPackageName();if(p!=null&&VOICE.contentEquals(p.toString())){if(pendingLead!=0)handler.postDelayed(this::tryStartCall,120);inspectCallState();}}
    @Override public void onInterrupt(){commandBusy=false;callState="Accessibility interrupted";refresh();}
    @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);if(live!=null)live.stop();if(tts!=null){try{tts.stop();tts.shutdown();}catch(Exception ignored){}}remove();instance=null;if(db!=null)db.close();super.onDestroy();}

    public void show(){db.prefs.edit().putBoolean("panel",true).apply();render();}
    public void hide(){db.prefs.edit().putBoolean("panel",false).apply();if(live!=null)live.stop();remove();}
    private void remove(){if(shell!=null){try{wm.removeView(shell);}catch(Exception ignored){}shell=null;}}
    private void refresh(){if(shell!=null)handler.post(this::render);}

    private AccessibilityNodeInfo voiceRoot(){
        AccessibilityNodeInfo r=getRootInActiveWindow();
        if(r!=null&&VOICE.contentEquals(pkg(r)))return r;
        for(AccessibilityWindowInfo w:getWindows())if(w.getType()==AccessibilityWindowInfo.TYPE_APPLICATION){r=w.getRoot();if(r!=null&&VOICE.contentEquals(pkg(r)))return r;}
        return null;
    }
    private String pkg(AccessibilityNodeInfo n){return n.getPackageName()==null?"":n.getPackageName().toString();}
    private List<AccessibilityNodeInfo> nodes(AccessibilityNodeInfo root){ArrayList<AccessibilityNodeInfo> out=new ArrayList<>();if(root==null)return out;ArrayDeque<AccessibilityNodeInfo> q=new ArrayDeque<>();q.add(root);while(!q.isEmpty()&&out.size()<700){AccessibilityNodeInfo n=q.remove();out.add(n);for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return out;}
    private String label(AccessibilityNodeInfo n){String a=n.getContentDescription()!=null?n.getContentDescription().toString():"";String b=n.getText()!=null?n.getText().toString():"";return (a+" "+b).trim();}
    private AccessibilityNodeInfo clickable(AccessibilityNodeInfo n){AccessibilityNodeInfo t=n;for(int i=0;i<4&&t!=null&&!t.isClickable();i++)t=t.getParent();return t!=null&&t.isClickable()?t:null;}
    private AccessibilityNodeInfo uniqueControl(AccessibilityNodeInfo root,String pref,String... accepted){String configured=db.prefs.getString(pref,"").trim();ArrayList<AccessibilityNodeInfo> m=new ArrayList<>();for(AccessibilityNodeInfo n:nodes(root))if(n.isVisibleToUser()&&n.isEnabled()){String l=label(n).trim();boolean ok=!configured.isEmpty()?configured.equals(n.getViewIdResourceName()):Arrays.stream(accepted).anyMatch(a->a.equalsIgnoreCase(l));if(ok){AccessibilityNodeInfo c=clickable(n);if(c!=null&&!m.contains(c))m.add(c);}}return m.size()==1?m.get(0):null;}
    private AccessibilityNodeInfo containsControl(AccessibilityNodeInfo root,String... accepted){ArrayList<AccessibilityNodeInfo> m=new ArrayList<>();for(AccessibilityNodeInfo n:nodes(root))if(n.isVisibleToUser()&&n.isEnabled()){String l=label(n).toLowerCase(Locale.US);boolean ok=Arrays.stream(accepted).anyMatch(a->l.contains(a.toLowerCase(Locale.US)));if(ok){AccessibilityNodeInfo c=clickable(n);if(c!=null&&!m.contains(c))m.add(c);}}return m.size()==1?m.get(0):null;}
    private AccessibilityNodeInfo numberField(AccessibilityNodeInfo root,String phone){String configured=db.prefs.getString("number_id","").trim();ArrayList<AccessibilityNodeInfo> result=new ArrayList<>();for(AccessibilityNodeInfo n:nodes(root))if(n.isVisibleToUser()&&n.isEnabled()&&n.isEditable()){String hint=n.getHintText()==null?"":n.getHintText().toString();String d=(label(n)+" "+hint).toLowerCase(Locale.US);boolean isPhone=(n.getInputType()&android.text.InputType.TYPE_MASK_CLASS)==android.text.InputType.TYPE_CLASS_PHONE;boolean same=phone.equals(Csv.phone(n.getText()==null?"":n.getText().toString()));if(!configured.isEmpty()?configured.equals(n.getViewIdResourceName()):isPhone||same||d.contains("phone number")||d.contains("enter a number")||d.contains("number to call"))result.add(n);}return result.size()==1?result.get(0):null;}

    private boolean maybeSelectAccount(AccessibilityNodeInfo root){String wanted=db.prefs.getString("voice_account","").trim();if(root==null||wanted.isEmpty())return false;ArrayList<AccessibilityNodeInfo> m=new ArrayList<>();for(AccessibilityNodeInfo n:nodes(root)){String l=label(n);if(n.isVisibleToUser()&&!l.isEmpty()&&l.toLowerCase(Locale.US).contains(wanted.toLowerCase(Locale.US))){AccessibilityNodeInfo c=clickable(n);if(c!=null&&!m.contains(c))m.add(c);}}if(m.size()==1){m.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);callState="Voice account selected";return true;}return false;}

    /** Initial CALL button. Every later call can start automatically after the post-call note window. */
    private void call(){
        if(commandBusy||preDial||postPause)return;
        if(db.prefs.getBoolean("call_unresolved",false)){callState="A call is already active · use HANG UP";refresh();return;}
        Store.Lead lead=db.current();if(lead==null){Ui.toast(this,"Import or add leads first");return;}if(lead.dnc){callState="Do not call: blocked lead";refresh();return;}
        if(db.activeLead()>0)db.defaultPendingNoAnswer();
        announceOwnerThenDial(lead);
    }

    private void announceOwnerThenDial(Store.Lead lead){
        if(lead==null||lead.dnc)return;queuedLead=lead.id;preDial=true;stage=0;mode="script";detectedObjection=null;liveText="";transcriptWindow="";pendingDisposition=null;connected=false;
        String first=firstName(lead.owner);callState=first.isEmpty()?"Contact ready · owner name unavailable · dialing next":"Contact ready · listen: "+first+" · "+first;render();
        if(!first.isEmpty()&&ttsReady&&tts!=null){try{tts.speak(first+". "+first+".",TextToSpeech.QUEUE_FLUSH,null,"owner:"+lead.id+":"+System.currentTimeMillis());handler.postDelayed(()->beginDialAfterIntro(lead.id),4200);return;}catch(Exception ignored){}}
        handler.postDelayed(()->beginDialAfterIntro(lead.id),first.isEmpty()?900:1400);
    }
    private String firstName(String owner){if(owner==null)return "";String s=owner.trim();if(s.isEmpty())return "";return s.split("\\s+")[0];}
    private void beginDialAfterIntro(long leadId){if(!preDial||queuedLead!=leadId)return;preDial=false;Store.Lead lead=db.lead(leadId);if(lead==null||lead.dnc)return;pendingLead=lead.id;prepareDeadline=System.currentTimeMillis()+14000;commandBusy=true;dialpadAttempted=false;callState="Opening Google Voice underneath Orynlo…";render();Intent launch=getPackageManager().getLaunchIntentForPackage(VOICE);if(launch==null){pendingLead=0;commandBusy=false;callState="Google Voice is not installed";refresh();return;}try{startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));handler.postDelayed(this::tryStartCall,500);}catch(Exception e){pendingLead=0;commandBusy=false;callState="Could not open Google Voice";refresh();}}

    private void tryStartCall(){
        if(pendingLead==0)return;Store.Lead lead=db.lead(pendingLead);if(lead==null||lead.dnc){pendingLead=0;commandBusy=false;return;}
        AccessibilityNodeInfo root=voiceRoot();
        if(root!=null&&maybeSelectAccount(root)){handler.postDelayed(this::tryStartCall,450);return;}
        AccessibilityNodeInfo field=numberField(root,lead.phone);
        if(field==null&&root!=null&&!dialpadAttempted){AccessibilityNodeInfo open=containsControl(root,"make a call","dialpad","dial pad","new call","call a number");if(open!=null){dialpadAttempted=true;open.performAction(AccessibilityNodeInfo.ACTION_CLICK);callState="Opening Voice dial pad…";refresh();handler.postDelayed(this::tryStartCall,450);return;}}
        if(field!=null){String current=field.getText()==null?"":field.getText().toString();if(!lead.phone.equals(Csv.phone(current))){Bundle a=new Bundle();a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,lead.phone);field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,a);handler.postDelayed(this::tryStartCall,260);return;}AccessibilityNodeInfo button=uniqueControl(root,"call_id","Call","Place call","Call "+lead.phone);if(button==null)button=containsControl(root,"call "+lead.phone,"place call");if(button!=null){boolean ok=button.performAction(AccessibilityNodeInfo.ACTION_CLICK);pendingLead=0;commandBusy=false;if(ok){db.attempt(lead.id,"Dial requested");db.prefs.edit().putBoolean("call_unresolved",true).commit();callRequestedAt=System.currentTimeMillis();connected=false;callState="Dialing · HANG UP is the only call-end action";startAssistIfEnabled();render();}else{callState="Voice did not accept Call";refresh();}return;}}
        if(System.currentTimeMillis()<prepareDeadline){handler.postDelayed(this::tryStartCall,350);return;}
        pendingLead=0;commandBusy=false;callState="Could not find Voice dial controls. Open Voice once, choose the saved account, then return to Orynlo.";refresh();
    }

    /** Manual call-end only: no automatic hangup and no automatic end-of-call inference. */
    private void hang(){
        if(commandBusy||postPause)return;if(!db.prefs.getBoolean("call_unresolved",false)){callState="No active call";refresh();return;}
        AccessibilityNodeInfo root=voiceRoot();AccessibilityNodeInfo b=uniqueControl(root,"hang_id","End call","Hang up","End Call");if(b==null)b=containsControl(root,"end call","hang up");if(b==null){callState="Hang-up control not found in Voice · call is still treated as active";refresh();return;}
        commandBusy=true;boolean ok=b.performAction(AccessibilityNodeInfo.ACTION_CLICK);callState=ok?"Hang-up requested":"Voice did not accept Hang up";handler.postDelayed(()->{commandBusy=false;if(ok)finishManualEnd();},700);refresh();
    }
    private void finishManualEnd(){db.prefs.edit().putBoolean("call_unresolved",false).commit();if(live!=null)live.stop();assistState="Live Assist off";connected=false;startPostCallPause();}

    /** We still inspect visible state for coaching only; it never ends a call automatically. */
    private void inspectCallState(){if(!db.prefs.getBoolean("call_unresolved",false))return;AccessibilityNodeInfo root=voiceRoot();if(root==null)return;String snap=snapshot(root).toLowerCase(Locale.US);if(TIMER.matcher(" "+snap+" ").find()||snap.contains("connected")){if(!connected){connected=true;callState="Connected · script tracking active";refresh();}}}
    private String snapshot(AccessibilityNodeInfo root){StringBuilder s=new StringBuilder();for(AccessibilityNodeInfo n:nodes(root)){String l=label(n);if(!l.isEmpty())s.append(l).append(' ');}return s.toString();}

    private void startPostCallPause(){
        postPause=true;noteEditing=false;int sec=Math.max(2,Math.min(60,db.prefs.getInt("post_call_seconds",8)));pauseEndsAt=System.currentTimeMillis()+sec*1000L;callState="Call ended · optional note window";render();handler.removeCallbacks(postPauseTick);handler.post(postPauseTick);
    }
    private final Runnable postPauseTick=new Runnable(){public void run(){if(!postPause||noteEditing)return;long left=Math.max(0,pauseEndsAt-System.currentTimeMillis());if(left<=0){finishPostCallAndDialNext();return;}callState="Optional note · next call auto-starts in "+Math.max(1,(left+999)/1000)+"s";render();handler.postDelayed(this,1000);}};
    private void openQuickNote(){if(!postPause||noteEditing)return;noteEditing=true;pausedRemaining=Math.max(2000,pauseEndsAt-System.currentTimeMillis());handler.removeCallbacks(postPauseTick);remove();Intent i=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("quick_note",true);startActivity(i);}
    public void resumeAfterNote(){if(!postPause)return;noteEditing=false;pauseEndsAt=System.currentTimeMillis()+Math.max(2000,pausedRemaining);show();handler.removeCallbacks(postPauseTick);handler.post(postPauseTick);}
    private void finishPostCallAndDialNext(){
        if(!postPause)return;postPause=false;noteEditing=false;handler.removeCallbacks(postPauseTick);
        if(db.activeLead()>0){if(pendingDisposition!=null)db.autoFinish(pendingDisposition,"Detected during call by Live Assist");else db.defaultPendingNoAnswer();}
        pendingDisposition=null;detectedObjection=null;liveText="";transcriptWindow="";Store.Lead next=db.move(1);stage=0;mode="script";
        if(next==null){callState="Queue complete · no next callable lead";render();return;}
        callState="Next contact loaded";render();handler.postDelayed(()->announceOwnerThenDial(next),500);
    }

    private void startAssistIfEnabled(){if(live==null)return;if(db.prefs.getBoolean("live_assist",false)){live.start();if(!live.supported())assistState="Live Assist may be blocked during VoIP on this device";}else assistState="Live Assist off";}
    private void handleTranscript(String text,boolean fin){
        if(text==null||text.trim().isEmpty())return;liveText=text;transcriptWindow=(transcriptWindow+" "+text).trim();if(transcriptWindow.length()>650)transcriptWindow=transcriptWindow.substring(transcriptWindow.length()-650);
        String machine=playbook.machineDisposition(transcriptWindow);if(machine!=null&&db.prefs.getBoolean("call_unresolved",false)){pendingDisposition=machine;callState=machine+" detected · tap HANG UP";refresh();return;}
        String objection=playbook.matchObjection(transcriptWindow);if(objection!=null){detectedObjection=objection;mode="objection";callState="Objection match · rebuttal ready";render();return;}
        if(fin&&mode.equals("script")&&System.currentTimeMillis()-lastAdvanceAt>1800&&playbook.stageSpoken(stage,transcriptWindow)){if(stage<playbook.stages.length()-1){stage++;lastAdvanceAt=System.currentTimeMillis();callState="Stage auto-tracked";render();}}else refresh();
    }

    public void render(){
        remove();shell=Ui.column(this);shell.setBackgroundColor(Ui.BG);shell.setPadding(Ui.dp(this,14),Ui.dp(this,8),Ui.dp(this,14),Ui.dp(this,10));
        params=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.START;
        Store.Lead lead=db.current();
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);TextView h=Ui.text(this,"ORYNLO  /  RAPID CALL COCKPIT",13,Ui.CYAN);h.setTypeface(null,android.graphics.Typeface.BOLD);header.addView(h,new LinearLayout.LayoutParams(0,-2,1));Button x=Ui.buttonColor(this,"×",Ui.CARD,this::hide);header.addView(x,new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,48)));shell.addView(header);
        renderContact(shell,lead);
        shell.addView(Ui.text(this,callState+(liveText.isEmpty()?"":"  ·  Heard: “"+ellipsize(liveText,54)+"”"),12,connected?Ui.GREEN:Ui.MUTED));

        if(postPause){renderPause(shell,lead);wm.addView(shell,params);return;}

        ScrollView sc=new ScrollView(this);LinearLayout body=Ui.column(this);sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        if(mode.equals("objection"))renderObjection(body,detectedObjection);else if(mode.equals("objection_list"))renderObjectionList(body);else renderScript(body);
        Ui.row(shell,Ui.buttonColor(this,"‹ SCRIPT",Ui.CARD,()->{stage=Math.max(0,stage-1);mode="script";render();}),Ui.buttonColor(this,"SCRIPT ›",Ui.CARD,()->{stage=Math.min(playbook.stages.length()-1,stage+1);mode="script";render();}),Ui.buttonColor(this,"OBJECTION",Ui.PURPLE,()->{mode="objection_list";render();}));
        Ui.row(shell,Ui.buttonColor(this,"CALL",Ui.GREEN,this::call),Ui.buttonColor(this,"HANG UP",Ui.RED,this::hang));
        wm.addView(shell,params);
    }
    private void renderContact(LinearLayout parent,Store.Lead l){LinearLayout c=Ui.card(parent);c.addView(Ui.label(this,"CONTACT",Ui.CYAN));if(l==null){c.addView(Ui.text(this,"No lead selected",16,Ui.MUTED));return;}String owner=(l.owner==null||l.owner.trim().isEmpty())?"Owner name not available":l.owner;String trucks=(l.trucks==null||l.trucks.trim().isEmpty())?"fleet size unknown":l.trucks+" trucks";c.addView(Ui.text(this,l.company,18,Ui.INK));c.addView(Ui.text(this,owner+"  ·  "+l.phone+"  ·  "+trucks,14,Ui.GREEN));String extra=((l.lanes==null?"":l.lanes.trim())+(l.email==null||l.email.trim().isEmpty()?"":"  ·  "+l.email)).trim();if(!extra.isEmpty())c.addView(Ui.text(this,extra,12,Ui.MUTED));}
    private void renderPause(LinearLayout parent,Store.Lead l){long left=Math.max(0,pauseEndsAt-System.currentTimeMillis());LinearLayout c=Ui.card(parent);c.addView(Ui.label(this,"POST-CALL PAUSE",Ui.AMBER));c.addView(Ui.text(this,"Next number auto-dials in "+Math.max(0,(left+999)/1000)+" seconds.",18,Ui.INK));c.addView(Ui.text(this,"No result selected = No answer. If Live Assist matched voicemail/intercept, that detected disposition is saved instead.",12,Ui.MUTED));c.addView(Ui.buttonColor(this,"NOTE (OPTIONAL)",Ui.PURPLE,this::openQuickNote));if(pendingDisposition!=null)c.addView(Ui.text(this,"Pending disposition: "+pendingDisposition,13,Ui.AMBER));}
    private void renderScript(LinearLayout body){JSONObject s=playbook.stage(stage);body.addView(Ui.label(this,"HOW TO SAY IT",Ui.AMBER));body.addView(Ui.text(this,s.optString("style"),15,Ui.AMBER));body.addView(Ui.text(this,s.optString("energy"),14,Ui.GREEN));LinearLayout card=Ui.card(body);card.addView(Ui.label(this,s.optString("title")+"  ·  "+(stage+1)+"/"+playbook.stages.length(),Ui.CYAN));card.addView(Ui.speech(this,playbook.personalize(s.optString("say"),db.current())));body.addView(Ui.label(this,"UNDERSTAND — DO NOT READ",Ui.MUTED));body.addView(Ui.text(this,s.optString("coach"),13,Ui.MUTED));body.addView(Ui.text(this,"Manual script + objection buttons are local and always available. Auto transcript matching runs only when Android recognition returns speech.",11,Ui.PURPLE));if(db.prefs.getBoolean("live_assist",false))body.addView(Ui.text(this,"Live Assist: "+assistState,12,Ui.PURPLE));}
    private void renderObjection(LinearLayout body,String name){JSONObject o=playbook.objection(name);if(o==null){mode="objection_list";renderObjectionList(body);return;}body.addView(Ui.label(this,"COACH FIRST — READ THIS SILENTLY",Ui.PURPLE));body.addView(Ui.text(this,o.optString("cue"),16,Ui.PURPLE));body.addView(Ui.label(this,"HOW TO SAY IT",Ui.AMBER));body.addView(Ui.text(this,o.optString("style"),15,Ui.AMBER));body.addView(Ui.text(this,o.optString("energy"),14,Ui.GREEN));LinearLayout card=Ui.card(body);card.addView(Ui.label(this,o.optString("title"),Ui.RED));card.addView(Ui.speech(this,playbook.personalize(o.optString("say"),db.current())));body.addView(Ui.buttonColor(this,"BACK TO SCRIPT",Ui.CARD,()->{mode="script";render();}));}
    private void renderObjectionList(LinearLayout body){body.addView(Ui.label(this,"TAP WHAT YOU HEARD",Ui.PURPLE));body.addView(Ui.text(this,"These buttons are local/offline and deterministic. If Live Assist hears a matching phrase, the same rebuttal opens automatically.",13,Ui.MUTED));for(String n:playbook.objectionNames())if(!n.equals("None"))body.addView(Ui.buttonColor(this,n,Ui.CARD,()->{detectedObjection=n;mode="objection";render();}));}
    private String ellipsize(String s,int n){return s.length()<=n?s:s.substring(0,n-1)+"…";}
}
