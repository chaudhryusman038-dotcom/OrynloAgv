package com.orynlo.voicedesk;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.speech.*;
import java.util.*;

/** Local-first speech assistant. Android may block concurrent mic capture during a VoIP call. */
public final class LiveCoach implements RecognitionListener {
    public interface Listener { void onText(String text,boolean isFinal); void onState(String state); }
    private final Context context; private final Listener listener; private final Handler h=new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer; private Intent intent; private boolean running=false,starting=false;
    public LiveCoach(Context c,Listener l){context=c;listener=l;}
    public boolean supported(){if(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)return false;if(Build.VERSION.SDK_INT>=31)return SpeechRecognizer.isOnDeviceRecognitionAvailable(context);return SpeechRecognizer.isRecognitionAvailable(context);}
    public void start(){if(running)return;if(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){listener.onState("Mic permission is off");return;}try{if(Build.VERSION.SDK_INT>=31&&SpeechRecognizer.isOnDeviceRecognitionAvailable(context))recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(context);else if(SpeechRecognizer.isRecognitionAvailable(context))recognizer=SpeechRecognizer.createSpeechRecognizer(context);else{listener.onState("Speech recognition unavailable");return;}recognizer.setRecognitionListener(this);intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-US").putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true).putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true).putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);running=true;listen();}catch(Exception e){listener.onState("Live Assist unavailable: "+e.getClass().getSimpleName());stop();}}
    private void listen(){if(!running||recognizer==null||starting)return;starting=true;h.postDelayed(()->{try{if(running)recognizer.startListening(intent);}catch(Exception e){listener.onState("Live Assist paused");}finally{starting=false;}},180);}
    private void restart(){if(!running)return;h.postDelayed(this::listen,450);}
    public void stop(){running=false;starting=false;h.removeCallbacksAndMessages(null);if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;}}
    private void deliver(Bundle b,boolean fin){if(b==null)return;ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(r!=null&&!r.isEmpty()&&r.get(0)!=null&&!r.get(0).trim().isEmpty())listener.onText(r.get(0).trim(),fin);}
    public void onReadyForSpeech(Bundle b){listener.onState("Listening");}public void onBeginningOfSpeech(){}public void onRmsChanged(float v){}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){}
    public void onError(int error){if(!running)return;if(error==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS){listener.onState("Mic permission is off");stop();return;}if(error!=SpeechRecognizer.ERROR_NO_MATCH&&error!=SpeechRecognizer.ERROR_SPEECH_TIMEOUT&&error!=SpeechRecognizer.ERROR_RECOGNIZER_BUSY)listener.onState("Live Assist limited on this call");restart();}
    public void onResults(Bundle b){deliver(b,true);restart();}public void onPartialResults(Bundle b){deliver(b,false);}public void onEvent(int t,Bundle b){}
}
