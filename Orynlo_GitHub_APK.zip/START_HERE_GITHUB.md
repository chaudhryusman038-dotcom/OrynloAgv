# Phone se GitHub par APK banana

Yeh ZIP Android source hai. APK GitHub Actions par compile hoga. Is workflow ko abhi GitHub par execute nahi kiya gaya; pehla run Android build/lint ko verify karega.

## Sabse aasan phone method (ZIP extract karna zaroori nahi)

1. GitHub website par apne account se new repository banao: `orynlo-voice-desk`. README initialize kar do. Private rakh sakte ho; Actions tumhare account ki availability/usage limits ke mutabiq chalega.
2. Repo → Add file → Upload files. **Orynlo_GitHub_APK.zip** as-is root par upload aur commit karo. Is ZIP ka naam mat badalna. GitHub ZIP khud extract nahi karta; included workflow karega.
3. Repo → Add file → Create new file. Filename EXACT yeh do:
   `.github/workflows/build-apk.yml`
4. Chat mein di gayi `build-apk.yml` file ka poora text is editor mein paste karo. Sirf file ka naam, link, ya markdown fences paste na karna. Default branch (normally `main`) par commit karo.
5. Repo → Actions → **Build Orynlo APK** → **Run workflow** → green **Run workflow** button.
6. Run ko open karo. Jab build successful green ho, neeche **Artifacts → Orynlo-APK** download karo.
7. GitHub artifact ZIP ko extract karo. Uske andar **Orynlo-Voice-Desk.apk** install karni hai. Source ZIP install nahi hoti.
8. Phone par app open karo; lead import/add karo; floating panel ka disclosure read karke Accessibility service enable karo. Apne test number se pehle verify karo.

Phone browser mein Add file/Actions controls nazar na aayen to browser ka Desktop site view use karo.

## Repository mein minimum do files

- `Orynlo_GitHub_APK.zip` (root)
- `.github/workflows/build-apk.yml` (workflow)

Sirf ZIP upload karne se Actions workflow register nahi hota. Workflow file `.github/workflows/` mein alag se hona lazmi hai.

## Computer/extracted-files method

Is ZIP ke CONTENTS repository root mein upload/push karo. `settings.gradle`, `app`, `tests` aur `.github` root par hon. Extra outer folder nahi hona chahiye. Included workflow phir directly source build karega. Dono methods supported hain.

## Agar red / failed run aaye

Failed step open karo aur pehla actual error bhejo. “Prepare Android project” fail ho to filename/path check karo. Android compile/lint fail ho to us error ko fix kiye baghair APK ko ready mat samjho. “Run workflow” missing ho to check karo file default branch par hai, path exactly correct hai, aur Actions allowed hai.

Yeh personal device-test/debug build hai. Google Voice controls abhi tumhare device par verify hone hain. Har clean GitHub runner naya debug signing key bana sakta hai: later APK updates ke liye stable private signing key configure karna hoga. Signature mismatch par uninstall se local data delete hota hai, isliye purani app ko blindly uninstall mat karna.

## Source references

https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow
https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts
