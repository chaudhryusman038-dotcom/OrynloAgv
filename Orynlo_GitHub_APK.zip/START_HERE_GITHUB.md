# Build Orynlo Rapid Call Cockpit

Upload this ZIP to the repository root with the exact name:

`Orynlo_GitHub_APK.zip`

Then run:

**Actions → Build Orynlo APK → Run workflow**

Expected app version: `0.3.0-rapid-call-cockpit`.

After installation, enable the Orynlo Accessibility service, grant microphone permission only if you want Live Assist, choose your Google Voice account in Setup if Voice repeatedly shows an account chooser, and set the post-hangup note/pause window.
