# Build Orynlo v0.5

1. Upload this ZIP to the repository root as `Orynlo_GitHub_APK.zip`.
2. Open GitHub Actions → Build Orynlo APK.
3. Run workflow on `main`.
4. Download the `Orynlo-APK` artifact.
5. Install `Orynlo-Voice-Desk.apk`.

Version: 0.5.0-manual-call-desk
