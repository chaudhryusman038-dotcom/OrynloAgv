# Orynlo — website, estimator & portal sales playbook

Revised to the owner’s correction, 29 September 2026. Audience: trucking company owners with 3–10+ trucks. Spoken US English.

## Offer

An easier way for shippers and customers to find the carrier’s services, contact it directly, receive a quick free preliminary estimate under carrier-approved rules, and manage shipment information through its own website and portal. Office staff manage requests, loads, documents, customer messages and invoices in one place. Orynlo sells the system and agreed setup; it does not promise traffic, loads or contracts.

## What changed from the existing web pitch

The existing web desk was inspected directly. Its website-visits-to-quote-requests angle has been replaced in this new app with the full website → estimate → customer portal → operations offer, following the owner’s correction. The existing live site itself is unchanged.

## Caller method

Acknowledge → diagnose the real concern → connect one relevant capability → ask for a specific next step. Avoid feature dumping, premature discounting, or immediately retreating from a soft objection. Ask a maximum of one respectful clarification after a plain “not interested”; stop at repeated refusal or an explicit opt-out.

## Conversation

### 01 · Confirm the owner

{first}?

Hi, this is Usman with Orynlo.

Caller note: Pause for confirmation. Gatekeeper: “Who handles your customer quoting process and company website?” Use your real introduction; no fake familiarity.

### 02 · The opener

We build trucking websites where customers can get a quick estimate and manage their shipments in one place. How are you handling quote requests right now?

Caller note: Deliver calmly in about 15 seconds, then stop talking. Your offer is a working customer-and-operations system. You are not taking responsibility for website traffic, loads, or signed shipper accounts.

### 03 · If they ask what you mean

A shipper can find your services, contact you directly, and get a quick, free estimate on your website. Then their shipment details, documents, and invoices can stay together in a customer portal—with your team managing the work from one dashboard.

Caller note: This expands the opener only when needed. The estimate is free to the shipper; building the system is a paid service. Estimate calculations use carrier-approved rules; final rates and availability remain under the carrier’s control.

### 04 · Find the bottleneck

When a new quote request comes in, who handles it—you or someone in the office?

Do they calculate and send each estimate manually?

Caller note: Ask one question at a time. Follow with the part that matches the answer: “And once the job is booked, where do the customer updates, PODs, and invoices live?” Listen for scattered texts/emails, repeat data entry, slow estimates, or customers chasing updates. Do not assume the pain.

### 05 · Understand their fleet

What equipment and lanes are you mainly running?

Are most customers coming through brokers, or do you have direct shipper accounts too?

Caller note: Truck count is context, not proof of buying power. Verify imported data only if useful: “Are you still running around {trucks} trucks?” For broker-only fleets explore current paperwork and repeat-customer handling before pitching direct-shipper workflow.

### 06 · Make the problem concrete

So [person] is handling [their manual process], and [their specific issue] is what takes the extra work. Have I got that right?

About how many times does that come up in a normal week?

Caller note: Use their own facts. If they say everything works, ask which step is still manual rather than declaring there is no opportunity. Quantify only what they confirm; do not invent hours saved.

### 07 · Show the right workflow

Here is how I would handle that: the customer enters the shipment details on your website, gets an estimate based on your pricing rules, and the request goes into your dashboard. You review it, confirm the job, and keep the customer updates, documents, and invoices together from there.

Caller note: Present the relevant part first. If their pain is invoicing, lead with invoices and documents. If it is quoting, lead with estimate intake and review. A configured estimate is not an unconditional final quote or automatic booking.

### 08 · Owner view: more than a form

Your team can see which requests need a response, manage booked loads, assign trucks, and handle customer messages and invoices in the same system. Customers have their own login to see their information without calling you for every document.

Caller note: Use this after interest, not as an opener feature dump. Optional: truck status/next-origin updates, PDF invoices, reminders, staff roles, and payment links. Maps, GPS, payments, and email depend on the agreed integrations and setup. Do not claim every client system has every feature live.

### 09 · Move to a demo

It will make more sense when you see it. Let me show you a customer requesting an estimate, then the same job in the owner’s dashboard. Is [specific time] or [specific alternative] better for a ten-minute look?

Caller note: Ask clearly. Do not say “maybe you don’t need it” before testing the fit. State prospect time zone. Only use actual available slots. If not ready for a meeting, offer a short relevant walkthrough and agree what they will review.

### 10 · Show credible work

I can walk you through the kind of website and portal work we have done for trucking businesses, and show the part that matches your operation.

Caller note: Use an authorized demo or sanitized copy of Brice Delivery / Gorshi Trucking work. Never expose live customer data, passwords, internal inboxes, or payments. Do not claim measured client results or current live integrations without checking them. The prior project workflows inform this offer, not a guarantee of every deployment’s present condition.

### 11 · Book the next step

What time zone should I use?

What is the best email for the walkthrough details?

Does anyone else need to see the quoting or operations side with you?

Great—[weekday/date], [time/time zone]. We will focus on [their specific issue].

Caller note: Ask separately and confirm their agreement. Save the agreed time in + Result. An email address alone is not a booked demo. If requested, confirm the business name and appropriate contact channel.

### 12 · Answer price directly

The price depends on whether you need the website and estimator, or the full customer and operations portal too. I do not want to quote you for features you will not use. Which part would matter most to you first?

Caller note: Once you have an approved starting price/range, say it directly before explaining scope. No number was supplied here, so none is invented. After scope is clear, provide setup cost, ongoing charges, integrations, support, delivery schedule, ownership, and exclusions in writing.

### 13 · Demo that earns the sale

Let us use one of your typical shipments. Here is what the customer enters, here is the estimate, and here is what your team receives.

Compared with how you handle it now, would this take a step off your team’s plate?

What would have to change for this to fit your operation?

Caller note: 10-minute demo: confirm problem (1 minute), shipper intake/estimate (3), owner review/load/documents/invoice (3), fit and next decision (3). Let the owner judge. Show only working functions; label mock data and unavailable integrations.

### 14 · Commercial close

Based on what you have shown me, I would start with [agreed scope] to handle [their problem]. The price is [actual agreed amount], with [actual ongoing costs], and the delivery plan is [agreed timeline].

Is there anything in that scope or price stopping us from moving forward?

Caller note: Ask, then listen. Resolve the specific concern. Do not discount before understanding it. If needed, reduce optional scope with their agreement rather than promising unpriced features.

### 15 · Clear commitment

Then I will send the agreement with that scope and the next steps. Once we have the agreed approval and onboarding details, we can start. Who should the agreement go to?

Caller note: Use only after genuine agreement. Confirm terms and payment process without inventing deposits. Closed / Won requires actual acceptance under your sales process, not just a friendly conversation.

### 16 · Follow-up that advances

Hi {first}, Usman with Orynlo. We spoke about [their quoting or paperwork issue]. When you looked at the walkthrough, which part looked useful—and what was missing?

Caller note: Use only when a real earlier discussion supports it. If they have not watched: “No problem. The key part is [relevant workflow]. Can we look at it together for ten minutes at [specific time]?” Do not shame them.

### 17 · Short voicemail

Hi {first}, Usman with Orynlo. We build trucking websites with quick estimates and customer portals, so quoting and shipment paperwork can stay in one place. My number is [your real callback number]. Again, [number].

Caller note: Keep it under about 25 seconds. Replace the callback placeholder. No unsupported urgency or claim that you have a load for them.

### 18 · Respect a clear stop

Understood. I will mark this number do not call. Thank you.

Caller note: One relevant clarification can handle a soft objection; repeated refusal is a stop. Do not keep selling after an explicit opt-out. Save Do not call immediately; the app blocks this number.

## Fast objections

Pass = a meaningful conversation reopened or an agreed next step. Fail = the response did not advance the conversation. Unscored is valid. Track the primary objection used on each call.

### We already have a website.

Good—does it let a customer get an automatic estimate and then access their shipment documents and invoices, or does it mainly show the company and a contact form?

[If basic] That is the part I am talking about adding. Let me show you the customer-to-dashboard workflow.

### We already have a quote form.

A form is a good start. Does it calculate a preliminary estimate from your pricing rules and put the request into the same place your team manages the load—or do you still work it out and move the details manually?

### We already use a TMS.

Which TMS are you using? Does your customer get the same easy estimate-and-portal experience through your company website?

We should look at what you already have before suggesting any changes. If the gap is only customer-facing, we can scope around that instead of replacing your operation.

### Not interested.

Understood—is that because you already have estimates and customer paperwork handled, or because it is not a priority right now?

[If they explain a gap] That is exactly the part I can show you in a short walkthrough.
[If they repeat no] Understood. Thanks for your time.

### Send me an email.

Absolutely. Which would be more useful to see—the automatic estimate or the customer-and-operations dashboard?

What is the best email? I will keep it focused on that. Would [specific day/time] work for a brief follow-up after you see it?

### I am busy / Call later.

Of course. I can keep the walkthrough to ten minutes. Is [specific time] or [alternative] better, and what time zone are you in?

### I am driving.

I will let you focus on the road. We can pick this up another time.

### How much does it cost?

It depends on whether we are building the website and estimator or the full portal as well. What would you want to solve first—quoting, customer updates, or invoices and documents? Then I can give you a price for that scope.

### We do not have the budget.

Understood. Is budget the only concern, or are you still deciding whether the system would be useful?

[If useful] We can price a smaller first phase around the part you need most. Which part would that be?

### Too expensive / Someone quoted less.

What does their scope include—the website alone, or automatic estimates, customer logins, and the operations side too?

Let us compare the actual work and ongoing charges. If my scope includes things you do not need, we can remove those and price the right first phase.

### We do not want another tool.

That is a fair concern. Which tools would your team still need to use? The goal is to bring the customer-facing steps and the relevant work together, not create another place to copy information. Let us map one shipment and see whether it actually reduces steps.

### Everything works fine.

Good. Which part still needs the most hands-on work—sending estimates, updating customers, finding PODs, or following up on invoices?

If one of those could run more smoothly, that is the part I would show you.

### Do you have loads for us?

Not on this call. I am talking about a system customers can use to reach you directly, get an estimate, and manage the shipment with your team. Are direct customer accounts part of what you want to build?

### A website will not bring me loads.

Agreed—a website alone does not create freight. What we build is the process after a customer finds you: direct contact, a quick estimate, then shipment details and paperwork in one place. How do you handle those steps today?

### Can you guarantee customers or loads?

No, and I would not make that promise. What we can define and demonstrate is the workflow: shipment details in, an estimate under your rules, then review and customer access to the job information. Is that the part you want to improve?

### Nobody visits our website.

Then I would not sell you on traffic numbers. Do referrals, existing customers, or prospects from your outreach need a simpler way to get an estimate or their documents? They can use the system directly without waiting for search traffic.

### We only work with brokers.

Understood. Do you still handle shipment updates, PODs, and invoices across different emails and messages?

If that side is the issue, we can focus the operations workflow there. If you want direct accounts later, the customer-facing side can be scoped separately.

### Referrals / Facebook are enough.

Keep using what brings you business. Once that person contacts you, how do they get an estimate and then their updates and paperwork? The system supports that next step rather than replacing your referral channel.

### I already have a web person.

Great. Are they also building the estimate logic and customer-and-operations portal, or mainly managing the public pages?

If that part is still missing, I can show you the workflow so you can decide how you want to handle it.

### I can build it myself.

You can. The part I would show you is the complete flow from an estimate through the portal and paperwork. Then you can compare doing the setup and maintenance yourself with having it built around your operation. Which piece are you planning to start with?

### Have you done this before?

Yes, we have worked on trucking websites and portal workflows. I can show you a relevant, authorized example and walk through the customer and owner sides. Would [specific time] work?

### I do not have time to manage it.

That is why the setup, training, and update responsibilities need to be clear. Which tasks would you want your team to handle, and which would you need support with? We can put that scope and any ongoing cost in writing.

### My dispatcher handles it.

That makes sense. Would it be useful to show both of you how the request reaches the dispatcher and what the customer can see? You can judge the business side and they can tell us whether the workflow fits.

### Factoring handles invoices.

Keep the factoring process you rely on. How are shipment documents and customer updates handled before the invoice reaches them? We should focus on any gap there and confirm compatibility before discussing a payment workflow.

### Customers will not use a portal.

Some will still call or email, and that should remain available. Which of your repeat customers regularly asks for the same updates or documents? We can start by showing whether self-service would be useful for that group.

### Drivers will not use another app.

We do not have to make a driver app the starting point. We can focus first on your customers and office team. What driver input, if any, would the workflow actually require?

### Automatic estimates could be wrong.

That is exactly why the pricing rules and exceptions need your approval. The output can be a preliminary estimate with final confirmation by your team. Which shipments would you never want priced automatically?

### We price every load differently.

Then we should separate standard shipments from exceptions. The system can collect complete details and send unusual loads for manual review. Would a preliminary estimate help for standard jobs, or is organized intake the better starting point?

### I need to think about it.

Of course. What do you need to work through—the workflow, the price, or whether the team would use it?

[Address the answer] What would be a reasonable time to make the next decision?

### I need to ask my partner.

Absolutely. What will matter most to them? Let us show both of you the relevant workflow so you do not have to explain the system secondhand. When could you both take a look?

### Are you selling something?

Yes—we build the website, estimator, and portal around the carrier’s workflow. I am trying to understand whether quoting or customer paperwork is something you want to improve before showing you the system.

### What exactly are you offering?

Your own trucking website connected to an automatic estimate and customer portal, plus the dashboard your team uses to manage requests, shipments, documents, and invoices. We scope it around the work you actually need.

### How did you get my number?

I got it from [the actual source for this lead]. This is a business call about your quoting and customer workflow. If you would prefer no further calls, I will mark that.

### I am not the owner.

Thanks. Who handles decisions about quoting and the customer portal? Could you point me to the right person?

### Do not call again.

Understood. I will mark this number do not call. Thank you.

## Demo and qualification checklist

Before demo: role/decision maker, equipment, current quote process, bottleneck, existing tools, agreed slot and time zone. During demo: one realistic shipment, customer view, owner view, integration dependencies. After demo: scope, actual price, recurring costs, support, ownership, timeline and next decision.

## Project-informed capabilities

Prior Brice Delivery and Gorshi work informs the estimate, customer portal, load operations, documents/PDF invoices and messaging workflow. Exact current production behavior was not re-audited in this task. Demo only capabilities you verify work in the specific environment. Live GPS, routing, email and payment verification depend on credentials, provider support and setup.

## Definitions

Interested = wants a relevant walkthrough. Qualified = confirmed operational need, decision process and mutually agreed next step. Closed/Won = actual agreement under your process. “Send email” alone is neither qualified nor won.