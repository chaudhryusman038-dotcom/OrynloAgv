#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/orynlo-core-tests
java -m jdk.compiler/com.sun.tools.javac.Main -d /tmp/orynlo-core-tests app/src/main/java/com/orynlo/voicedesk/Csv.java tests/CoreTests.java tests/SyntaxCheck.java
java -cp /tmp/orynlo-core-tests CoreTests
java -cp /tmp/orynlo-core-tests SyntaxCheck
python3 tests/schema_check.py
