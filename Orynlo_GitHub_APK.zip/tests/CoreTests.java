import com.orynlo.voicedesk.Csv;
import java.util.*;
public class CoreTests {
    static int checks=0;
    static void check(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
    public static void main(String[]args){
        var r=Csv.parse("\uFEFFCompany,Phone,Notes\r\n\"A, B\",(312) 555-0100,\"Line 1\nLine 2 and \"\"quote\"\"\"\r\n");
        check(r.size()==2,"quoted newline not a new record");
        check(r.get(1).get(0).equals("A, B"),"quoted comma");
        check(r.get(1).get(2).contains("\"quote\""),"escaped quote");
        check(Csv.phone(r.get(1).get(1)).equals("+13125550100"),"US normalization");
        check(Csv.phone("+1 312-555-0100").equals(Csv.phone("3125550100")),"duplicate key");
        check(Csv.phone("0123456789").isEmpty(),"invalid area code");
        check(Csv.phone("3121550100").isEmpty(),"invalid exchange");
        check(Csv.phone("+44 20 7946 0958").isEmpty(),"unsupported country");
        check(Csv.phone("3125550100 ext 4").isEmpty(),"extensions require review");
        check(Csv.cell("=HYPERLINK(\"x\")").startsWith("\"'="),"formula injection neutralized");
        check(Csv.cell("  +SUM(1)").startsWith("\"'"),"whitespace formula neutralized");
        check(Csv.parse("A,B\n,\n").get(1).size()==2,"empty fields");
        check(Csv.parse("A,B\n\"\",\"\"").get(1).size()==2,"empty quoted last field");
        boolean failed=false;try{Csv.parse("A\n\"broken");}catch(IllegalArgumentException e){failed=true;}check(failed,"malformed CSV aborts");
        check(Csv.get(List.of("Acme","3125550100"),List.of("companyname","phonenumber"),"phone","phone number").equals("3125550100"),"header alias");
        System.out.println(checks+" CSV/phone checks passed");
    }
}
