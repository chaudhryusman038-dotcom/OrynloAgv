import pathlib,re,sqlite3,json,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/orynlo/voicedesk/Store.java').read_text()
db=sqlite3.connect(':memory:');db.execute('PRAGMA foreign_keys=ON')
for sql in re.findall(r'db\.execSQL\("(CREATE [^"]+)"\)',s):db.execute(sql)
db.execute("INSERT INTO leads(company,phone) VALUES ('Test carrier','+13125550100')")
db.execute("UPDATE leads SET status='Do not call',dnc=1,notes='keep history' WHERE id=1")
db.execute("INSERT OR IGNORE INTO leads(company,phone) VALUES ('Reimported','+13125550100')")
assert db.execute('SELECT count(*) FROM leads').fetchone()[0]==1
assert db.execute('SELECT dnc,notes FROM leads').fetchone()==(1,'keep history')
try:db.execute("INSERT INTO calls(lead,started) VALUES (999,1)");raise AssertionError('FK not enforced')
except sqlite3.IntegrityError:pass
db.execute("INSERT INTO calls(lead,started,status) VALUES (1,1,'Dial requested')")
db.execute("UPDATE calls SET status='Interested',finished=2 WHERE id=1")
assert db.execute('SELECT count(*) FROM calls').fetchone()[0]==1
for f in (root/'app/src/main').rglob('*.xml'):ET.parse(f)
j=json.loads((root/'app/src/main/assets/playbook.json').read_text())
assert len(j['stages'])>=8 and len(j['objections'])>=12
assert len({o['title'] for o in j['objections']})==len(j['objections'])
for st in j['stages']:
    assert all(st.get(k) for k in ('title','style','energy','say','coach','keywords'))
for o in j['objections']:
    assert all(o.get(k) for k in ('title','patterns','cue','style','energy','say'))
assert 'quick question' in j['stages'][0]['say'].lower()
assert 'website' not in j['stages'][0]['say'].lower()
assert 'less interruption' in ' '.join(x['say'] for x in j['stages']).lower()
assert j.get('machine_audio',{}).get('voicemail_patterns')
print('SQLite schema, duplicate/DNC preservation, foreign keys, XML and automation playbook checks passed')
