import pathlib,re,sqlite3,json,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/orynlo/voicedesk/Store.java').read_text()
db=sqlite3.connect(':memory:');db.execute('PRAGMA foreign_keys=ON')
for sql in re.findall(r'db\.execSQL\("(CREATE [^"]+)"\)',s):db.execute(sql)
db.execute("INSERT INTO leads(company,phone) VALUES ('Test carrier','+13125550100')")
db.execute("UPDATE leads SET status='Do not call',dnc=1,notes='keep history' WHERE id=1")
db.execute("INSERT OR IGNORE INTO leads(company,phone) VALUES ('Reimported','+13125550100')")
assert db.execute('SELECT count(*) FROM leads').fetchone()[0]==1
assert db.execute('SELECT dnc,notes FROM leads').fetchone()==(1,'keep history')
try:db.execute("INSERT INTO calls(lead,started) VALUES (999,1)");raise AssertionError('FK not enforced')
except sqlite3.IntegrityError:pass
for f in (root/'app/src/main').rglob('*.xml'):ET.parse(f)

j=json.loads((root/'app/src/main/assets/playbook.json').read_text())
assert 6 <= len(j['stages']) <= 10
assert len(j['objections']) >= 12
assert len({o['title'] for o in j['objections']})==len(j['objections'])
for st in j['stages']:assert all(st.get(k) for k in ('title','style','energy','say','coach','keywords'))
for o in j['objections']:assert all(o.get(k) for k in ('title','patterns','cue','style','energy','say'))
first=j['stages'][0]['say'].lower()
assert 'quick question' not in first
assert 'mind if i take 20 seconds' in first
assert 'website' not in first
all_say=' '.join(x['say'] for x in j['stages']).lower()
assert 'fewer interruptions' in all_say
assert 'about a week' in all_say
qualifiers=sum('?' in x['say'] for x in j['stages'][2:4])
assert qualifiers==2
print('SQLite, XML and short permission-based playbook checks passed')

voice=(root/'app/src/main/java/com/orynlo/voicedesk/VoiceService.java').read_text()
assert 'TAP TO COPY' in voice and 'copyPhone' in voice
assert '‹ PREVIOUS' in voice and 'NEXT ›' in voice
assert 'SCRIPT' in voice and 'OBJECTIONS' in voice
assert 'FLAG_NOT_TOUCH_MODAL' in voice and 'dragPanel' in voice and 'panel_size_level' in voice
assert 'fullParams()' in voice, 'Script/rebuttal surfaces must be full-screen'
for forbidden in ['SpeechRecognizer','tryStartCall','toggleSpeaker','performGlobalAction','ACTION_SET_TEXT','HANG UP','FIX VOICE']:
    assert forbidden not in voice, f'manual-first service must not contain {forbidden}'
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
for forbidden in ['RECORD_AUDIO','RECEIVE_BOOT_COMPLETED','POST_NOTIFICATIONS','ReminderReceiver']:
    assert forbidden not in manifest
ax=(root/'app/src/main/res/xml/accessibility.xml').read_text()
assert 'canRetrieveWindowContent="false"' in ax
print('Manual overlay, navigation, privacy and no-background automation checks passed')
