import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.nio.file.*;
import java.util.*;
public class SyntaxCheck {
    public static void main(String[] args)throws Exception{
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try(StandardJavaFileManager files=compiler.getStandardFileManager(diagnostics,null,null)){
            List<java.io.File> sources=new ArrayList<>();try(var paths=Files.walk(Path.of("app/src/main/java"))){paths.filter(p->p.toString().endsWith(".java")).forEach(p->sources.add(p.toFile()));}
            JavacTask task=(JavacTask)compiler.getTask(null,files,diagnostics,List.of("-proc:none"),null,files.getJavaFileObjectsFromFiles(sources));
            task.parse();boolean errors=false;for(var d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR){errors=true;System.err.println(d);}
            if(errors)throw new AssertionError("Java parse errors");
            System.out.println(sources.size()+" Java files parsed; Android type checking NOT performed");
        }
    }
}
